# System Overview — Session 1 Foundation

## Current boundary

Session 1 is delivered as connected vertical slices. Slice 1.0 establishes only the execution environment and minimal hello applications; it does not introduce authentication, database access, API contracts, product features, or mock data.

```text
Browser ──> Next.js web application (port 3000)
                    \
                     \  [future authenticated API calls]
                      \
                       Express API (port 4000)

PostgreSQL, Redis, and Mailpit are local infrastructure dependencies provisioned now for later Session 1 slices.
```

## Current deployable units

- `@windels/api`: Express/TypeScript service.
- `@windels/web`: Next.js/TypeScript web application.

## Deferred boundaries

Prisma data access, authentication, RBAC, email delivery, dashboard APIs, and all marketplace modules are deferred to their explicitly scheduled slices.
