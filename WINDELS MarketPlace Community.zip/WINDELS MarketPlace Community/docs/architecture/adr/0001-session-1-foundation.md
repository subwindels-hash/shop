# ADR-0001: Session 1 Foundation

- **Status:** Accepted
- **Date:** 2026-07-23
- **Scope:** Session 1, Slice 1.0

## Context

WINDELS requires a production-oriented, deployable full-stack foundation but must be built incrementally as vertical slices. The workspace was empty at the beginning of Session 1.

## Decisions

1. Use a pnpm workspace with two deployable applications: `apps/api` and `apps/web`.
2. Use Node.js 20.20+ with Express and TypeScript for the API; use Next.js App Router, React, TypeScript, and Tailwind CSS for the web application.
3. Use PostgreSQL 16, Redis 7, and Mailpit in local Docker Compose. PostgreSQL satisfies the platform requirement of PostgreSQL 15+.
4. Use Prisma for the Session 1 database schema and additive migrations, beginning in Slice 1.2.
5. Use native `fetch`, TanStack Query, and Zustand for the frontend, beginning in Slice 1.3.
6. Restrict public registration to Customer accounts. Privileged roles may not be self-assigned.
7. Pin package resolution through `pnpm-lock.yaml`; require Node 20.20+ and pnpm 10.13+.
8. Use ESLint, Prettier, TypeScript strict mode, Vitest, and CI quality checks from Slice 1.0.
9. Use Tailwind CSS v4's CSS-first setup. A legacy `tailwind.config.ts` is not created unless a later design-token need requires it.
10. Use Vercel for the Next.js staging deployment and Railway for the Express API, PostgreSQL, and Redis staging services. Use native provider Git integrations from a protected `staging` branch; GitHub Actions runs validation only and contains no cloud deployment tokens.

## Security baseline

- No secrets are committed; `.env` files are ignored and examples contain only local placeholder values.
- Future auth uses the fixed bearer-token API convention, short-lived access tokens, rotating refresh tokens, Argon2id password hashes, and backend RBAC enforcement.
- Authentication and privileged-route details are intentionally deferred until Slice 1.4 rather than partially implemented now.

## Consequences

- The frontend and API can be independently built and containerized from this slice.
- Database, Redis, and email infrastructure can be started locally before later slices consume them.
- The final staging deployment criterion is blocked until a hosting provider, DNS, secrets, managed Postgres/Redis, and sender domain are selected.

## Slice 1.0 verification

- Formatting, linting, strict type checking, Vitest invocation, and production builds passed locally on 2026-07-23.
- The Express hello endpoint and Next.js hello page were started from their production builds and verified locally.
- Docker Compose syntax and the provider-specific deployment path could not be exercised in this workspace because Docker and a staging provider are unavailable.
- Per the specification, Slice 1.0 is therefore blocked rather than marked complete until both applications are deployed and reachable in staging.

## Staging configuration

- `apps/web/vercel.json` contains only monorepo install/build configuration. The Vercel project Root Directory is `apps/web`.
- Root `railway.toml` retains the repository root as Docker context, selects `apps/api/Dockerfile`, limits watched paths, and uses `/` only until Slice 1.1 supplies the versioned health endpoint.
- The provider setup is documented without credentials in `docs/runbooks/vercel-railway-staging.md`.
- The staging branch has been added to CI triggers so its pull requests and pushes receive the same quality checks as `main`.

## Provider-configuration verification

- `apps/web/vercel.json` parsed as valid JSON and `railway.toml` parsed as valid TOML on 2026-07-23.
- The complete local quality suite and production runtime smoke checks passed after the provider configuration was added.
- Actual Vercel/Railway deployment is an external gate requiring authenticated provider and GitHub access; it has not been represented as completed.
