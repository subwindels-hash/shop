# Local Development Runbook

## Prerequisites

Install Node.js 20.20+ and Docker with Docker Compose. Corepack is bundled with supported Node releases.

## Initial setup

```bash
corepack pnpm install
cp .env.example .env
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env.local
corepack pnpm dev:infra
corepack pnpm dev
```

## Local service checks

```bash
curl http://localhost:4000/
# Expected: {"service":"windels-api","message":"Hello, API"}
```

Open <http://localhost:3000> to view the frontend hello page. Open <http://localhost:8025> to view Mailpit.

## Stop local infrastructure

```bash
corepack pnpm dev:infra:down
```

To remove local development volumes as well:

```bash
docker compose down --volumes
```

Do not use local Compose passwords or data for staging or production.
