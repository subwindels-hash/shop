# Vercel + Railway Staging Runbook

## Purpose and current scope

This runbook deploys the **Session 1 Slice 1.0** hello applications only:

- Next.js web application on Vercel
- Express API on Railway
- Railway PostgreSQL and Redis services provisioned for later Session 1 slices

The application has no authentication, database access, email delivery, or real business data at this point. Do not present this deployment as production-ready.

## Prerequisites

- A GitHub repository containing this workspace.
- A protected `staging` branch pushed to that repository.
- Access to the target Vercel team and Railway workspace.
- The current repository CI workflow passing on `staging`.

If this workspace has not yet been initialized as a Git repository, perform these commands from an authorized developer machine after setting the appropriate Git author identity:

```bash
git init -b main
git add .
git commit -m "chore: establish Session 1 Slice 1.0 foundation"
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
git switch -c staging
git push -u origin staging
```

Do not commit `.env` files, provider credentials, generated build artifacts, or local Docker data.

## GitHub branch protection

Protect the `staging` branch before allowing team changes to deploy:

1. Require pull requests before merge.
2. Require the `Continuous Integration / Quality checks` check to pass.
3. Restrict direct pushes to authorized release engineers.
4. Require current review policy appropriate to the organization.

Native Vercel and Railway Git integrations deploy new commits on `staging`; branch protection is the quality gate that prevents unreviewed deployments.

## Vercel — web staging project

1. In Vercel, create a project named `windels-web-staging` from the GitHub repository.
2. Set **Root Directory** to `apps/web`.
3. Set **Production Branch** to `staging`. This is a staging-only Vercel project; it must not be reused as the future production project.
4. Set the Node.js runtime to `20.x` to match the repository engine policy.
5. Keep the build settings supplied by `apps/web/vercel.json`:
   - Install: `corepack pnpm install --frozen-lockfile --filter @windels/web...`
   - Build: `corepack pnpm --filter @windels/web build`
6. Deploy the `staging` branch once to generate the default `*.vercel.app` URL.
7. Set `NEXT_PUBLIC_APP_URL` to that HTTPS URL for the **Production** environment of this staging project.
8. After the Railway API URL exists, set `NEXT_PUBLIC_API_BASE_URL` to the Railway HTTPS API URL. Redeploy because `NEXT_PUBLIC_*` values are embedded during the Next.js build.

No Vercel secrets are needed for Slice 1.0. Do not add future JWT, database, or payment credentials to Vercel.

## Railway — staging project and services

1. In Railway, create a project/environment named `windels-staging`.
2. Add a GitHub-backed API service named `windels-api-staging` from the repository and select the `staging` branch.
3. Keep the API service **Root Directory unset** (repository root). The API Dockerfile copies workspace-root files such as `pnpm-lock.yaml`, `pnpm-workspace.yaml`, and `tsconfig.base.json`.
4. Railway discovers the root `railway.toml`, which selects `apps/api/Dockerfile`, watches only API/workspace build inputs, and probes `/` during this hello-stage deployment.
5. Add a PostgreSQL service and a Redis service to the same Railway project. They are intentionally provisioned now but not consumed by application code until later Session 1 slices.
6. Add these API service variables:

   ```text
   NODE_ENV=production
   LOG_LEVEL=info
   CORS_ALLOWED_ORIGIN=<VERCEL_STAGING_HTTPS_URL>
   ```

   Railway provides `PORT` to the API service. The API reads this value and listens on it. Do not add real JWT, SMTP, database, Redis, or third-party credentials until their owning slices implement and validate them.

7. Under **Settings → Networking**, generate a public HTTPS domain for `windels-api-staging`.
8. Confirm the Railway deployment reports its `/` health check as successful.

## Native Git deployment behavior

- A successful merge or authorized push to `staging` causes Vercel and Railway to deploy through their connected Git integrations.
- `.github/workflows/ci.yml` validates `main` and `staging` but intentionally does not contain provider tokens or deployment commands.
- Provider dashboard access, GitHub OAuth connections, and their secrets remain outside this repository.

## Slice 1.0 external verification

After the first deployments complete, run from an authorized terminal:

```bash
curl --fail --silent --show-error "https://<RAILWAY_API_DOMAIN>/"
# Expected JSON contains: "service":"windels-api" and "message":"Hello, API"

curl --fail --silent --show-error "https://<VERCEL_WEB_DOMAIN>/" | grep "Hello, World"
```

Also verify:

- Vercel build succeeds and serves the WINDELS hello page over HTTPS.
- Railway builds from `apps/api/Dockerfile`, starts successfully, and marks `/` healthy.
- Railway PostgreSQL and Redis are available only through private networking; do not expose either publicly.
- The deployed URLs are recorded in the deployment ticket or approved environment inventory, never in source files that require a secret.

Only after both URLs pass these checks may Slice 1.0 be marked complete and Slice 1.1 start.

## Rollback

There are no migrations in Slice 1.0. For a failed staging release:

1. Stop promotion and retain provider logs.
2. Redeploy the previous successful deployment from the Vercel or Railway dashboard.
3. Confirm the preceding deployment again serves the expected hello response.
4. Create an incident/change record before retrying.

## Planned follow-up changes

- **Slice 1.1:** replace Railway's temporary `/` health check with `/api/v1/health` after the real health endpoint is implemented.
- **Slice 1.2:** connect the API to Railway PostgreSQL, add Prisma migrations, and configure database variables through Railway reference variables.
- **Slice 1.3:** make the deployed web application call the live API and enforce the final CORS policy.
