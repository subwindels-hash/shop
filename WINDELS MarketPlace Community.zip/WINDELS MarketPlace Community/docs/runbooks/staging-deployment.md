# Staging Deployment Runbook

## Status

**Target selected and repository configuration prepared:** Vercel will host the Next.js web application and Railway will host the Express API, PostgreSQL, and Redis. Slice 1.0 remains blocked until the authenticated provider setup, external deployments, and public URL verification are complete. No placeholder deployment workflow will be treated as a production deployment path.

For the selected provider-specific steps, see `docs/runbooks/vercel-railway-staging.md`.

## Required before deployment can be enabled

1. Hosting target for Next.js and Express, or a container platform for both.
2. Managed PostgreSQL 15+ and Redis endpoint with TLS requirements.
3. Staging DNS names and HTTPS certificate strategy.
4. SMTP/email-provider credentials and an approved sender domain.
5. Secret-management location for JWT keys, database credentials, API URL, and future third-party credentials.
6. Git repository access and deployment-environment protection rules.
7. Backup, rollback, migration, observability, and incident-contact requirements.

## Deployment guardrails

- Run additive database migrations before application rollout.
- Use separate staging secrets and infrastructure; never reuse local `.env` values.
- Require CI quality checks before deployment.
- Configure a health check and document rollback before enabling automated deployment.
- Add `.github/workflows/deploy-staging.yml` only after the provider-specific implementation is known.
