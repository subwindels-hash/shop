# Local Docker Services

`docker-compose.yml` provides infrastructure for local development only:

| Service       | Local address           | Purpose                                             |
| ------------- | ----------------------- | --------------------------------------------------- |
| PostgreSQL 16 | `localhost:5432`        | Application database for Session 1 Slice 1.2 onward |
| Redis 7       | `localhost:6379`        | Caching/rate-limit/session support for later slices |
| Mailpit SMTP  | `localhost:1025`        | Captures development email                          |
| Mailpit UI    | `http://localhost:8025` | Views captured development email                    |

Credentials and ports come from the root `.env` file, created by copying `.env.example`. Never use this setup in staging or production.
