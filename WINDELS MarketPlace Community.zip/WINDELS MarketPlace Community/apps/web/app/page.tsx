export default function HomePage() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 p-6 text-slate-950">
      <section className="max-w-xl rounded-xl border border-slate-200 bg-white p-8 shadow-sm">
        <p className="text-sm font-semibold tracking-[0.18em] text-blue-700">WINDELS</p>
        <h1 className="mt-3 text-3xl font-bold tracking-tight">Hello, World</h1>
        <p className="mt-3 text-slate-600">WINDELS MarketPlace Community foundation is running.</p>
      </section>
    </main>
  );
}
