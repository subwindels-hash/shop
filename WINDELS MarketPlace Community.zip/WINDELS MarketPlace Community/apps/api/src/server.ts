import { createApp } from "./app.js";
import { env } from "./config/env.js";

const app = createApp();

const server = app.listen(env.PORT, () => {
  process.stdout.write(`WINDELS API listening on port ${env.PORT}\n`);
});

const shutdown = (signal: NodeJS.Signals): void => {
  process.stdout.write(`Received ${signal}; shutting down WINDELS API.\n`);
  server.close(() => process.exit(0));
};

process.once("SIGINT", () => shutdown("SIGINT"));
process.once("SIGTERM", () => shutdown("SIGTERM"));
