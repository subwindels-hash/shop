import express, { type Express } from "express";

export const createApp = (): Express => {
  const app = express();

  app.disable("x-powered-by");

  app.get("/", (_request, response) => {
    response.status(200).json({
      service: "windels-api",
      message: "Hello, API"
    });
  });

  return app;
};
