# CLAUDE.md — WINDELS MarketPlace Community

This file gives Claude (and Claude Code) persistent context for working on this repository. Read it in full at the start of every session before writing any code.

---

## 1. Project Identity

- **Full Name:** WINDELS MarketPlace Community.
- **Spec Version:** 4.8 Enterprise Edition (current) — supersedes v3.0 → v3.1 → v3.2 → v3.3 → v3.4 → v3.5 → v3.6 → v3.7 → v4.1 → v4.2 → v4.3 → v4.4 → v4.6 → v4.7 → v4.8. Every version is an **additive, fully backward-compatible** extension; nothing in an earlier version is broken, removed, or restructured by a later one.
- **Spec Files:**
  - `WINDELS_Enterprise_Specification_v3_0.pdf` (104 pages — Parts I–VII, Steps 1–125). Core marketplace, location control module, infrastructure.
  - **v3.1 update (Part VIII, Steps 126–128)** — Enterprise AI, Security & Communication Platform. See Section 18.
  - **v3.2–v4.6 update (Parts IX–XX, XXII, Steps 129–290)** — the full enterprise/platform/governance/engineering-blueprint expansion. See **Section 20**.
  - **v4.7 update (11 capability requests, no new Parts/Steps)** — a no-duplication expansion pass requested via `update_.txt`: 3D/360° product & event media, workflow engine, AI agent marketplace, developer platform, AI command center, BI center, app store, AI knowledge base, audit & compliance center, communication hub, white-label platform. Every one of these 11 requests already had an existing home somewhere in Parts IX–XX below; **none required a new Part or Step number** — each is merged into its existing module. See **Section 20.13** for the full merge report.
  - **v4.8 update (4 capability requests, no new Parts/Steps)** — a second no-duplication expansion pass: vendor-controlled affiliate program, global branding footer component, external gift card payment/settlement integration, and the 200-agent AI Customer Care workforce with visual product discovery. All four already had an existing home in Sessions 9, 17/20, and 25 below; **none required a new Part or Step number**. See **Section 20.14** for the full merge report.
  - **Known gaps in the supplied spec text:** Part XVI (Steps 191–200) and Part XXI (Steps 271–280) were never provided/pasted — those step ranges are reserved but currently undefined. Do not invent content for them; flag it to the product owner if a session would need them.
- **Total Steps:** 290 (Steps 1–290, with the two gaps noted above still open)
- **Total Sessions:** 25 (see Section 5 — Session Roadmap)
- **Nature of the platform:** What began as a large multi-vendor marketplace has, across versions, grown into a full **Enterprise Commerce Operating System**: marketplace + fintech (wallet/escrow/gift cards) + AI (search, recommendations, AI-SOC, AI Agent OS) + cybersecurity + governance/compliance + developer/partner ecosystem (app store, low-code, integrations) + the engineering blueprint needed to actually build and operate all of it (API/event/DB/architecture repositories, testing, DevSecOps, observability). Supports vendor types: **General, Food, Digital, Service**, plus B2B/B2C/C2C, bookings, subscriptions, rentals, and auctions per Part IX.
- **Important editorial note carried over from the source spec:** the spec text itself repeatedly says, at v3.5, v3.6, v4.1, v4.2, and v4.3, some version of *"this should be the final addition — stop adding core functional modules, focus on implementation."* Each time, more parts were added anyway. Treat this as a real signal: before starting any new Part beyond XXII, check with the product owner whether it's actually needed, rather than assuming the spec should keep growing. See the "Feature-Freeze Recommendations" callout in Section 20.

---

## 2. Global Development Rules (apply to every session, every step)

These rules govern *how* Claude should behave throughout the whole build, not just what to build.

1. Generate only the features requested in the current step. **Do not implement future features prematurely.**
2. Wait for explicit confirmation before proceeding to the next step.
3. Before writing any code for a session, **show the complete folder/file structure** that will be created or modified, and explain where every new file goes and why. (The user will literally ask: *"Before writing any code, show me the folder structure you plan to use — including where each new file will go and why."*)
4. Analyze all previous work completed in earlier sessions before starting a new one. Maintain consistency with previous architectural decisions.
5. Do not skip any step. Do not skip Session 11 (integration) — it is explicitly called out as commonly skipped and critical.
6. Ensure all modules remain compatible with future integrations (esp. the Vendor Location Control Module, which touches nearly everything).
7. Follow enterprise-grade coding standards. Build **production-ready code only** — no throwaway prototypes.
8. Maintain scalability, security, maintainability, and performance standards at all times.
9. At the **end of every session**, produce an **Architecture Decision Log** (see Section 7) and append it to the running conventions log.
10. The user will ask at the end of every session: *"What decisions did you make this session — naming conventions, architectural choices, library picks, patterns — that I should add to my conventions log?"* — always answer this concretely, not generically.

### Critical Rules by phase
- **Vertical slice architecture, from Session 1 onward.** The application is built slice-by-slice, not layer-by-layer. A slice (e.g. Authentication, User Management, Admin Dashboard) is only "done" when its backend, database, and frontend are all built, wired together, tested, and deployed — never build a layer in isolation and leave it dangling for a future session to connect.
- **No mock data for foundational slices.** Because backend, DB, and frontend for a slice ship together, Session 1 frontend components call real APIs against a real (even if minimal) database from the start. There is no separate "mock-data frontend" phase — the parallelization that used to happen across layers now happens across slices instead.
- **The app must be deployable after every slice.** Each slice in Session 1 (see Section 5) ends with a working build that can be started, logged into, and clicked through end-to-end. If a slice can't be deployed and demoed, it isn't finished.
- **Every session after Session 1 builds on a stable, production-ready foundation.** Because Session 1 already delivers a fully functional (if minimal) app — DB, backend, frontend, auth, user/admin management, and role-based dashboards all wired together — later sessions are additive: they extend existing slices or add new ones on top of a live, testable system, rather than assembling the first working version out of previously-disconnected pieces.
- **Integration is continuous, not a one-time event.** The old model deferred cross-module integration to a single dedicated pass; the vertical-slice model instead verifies integration (frontend ↔ backend ↔ DB ↔ auth/permissions) at the end of every slice. Session 11's platform-wide integration pass (Section 5) still applies, but as a full-system regression check across everything built by then — not as the first time modules are connected to each other.

---

## 3. Technology Stack (authoritative — do not substitute without logging a decision)

| Component | Technology |
|-----------|-----------|
| Frontend | Next.js 14+ (App Router), React, TypeScript, Tailwind CSS |
| Backend | Node.js, Express.js, TypeScript |
| Database | PostgreSQL 15+ with read replicas |
| Auth | JWT + refresh tokens, Role-Based Access Control (RBAC) |
| File Storage | Amazon S3 or Cloudflare R2 + CDN |
| Queue | Redis + Bull / RabbitMQ |
| Search | Elasticsearch / Meilisearch |
| Caching | Redis (with explicit invalidation strategy) |
| Real-time | Socket.io / WebSockets |
| Geo-IP | MaxMind GeoIP2 / IP2Location |
| Location DB | GeoNames + custom hierarchical tables (countries → states → cities) |
| Monitoring | Grafana, Prometheus (per spec, Part IV) |

---

## 4. User Role Hierarchy (RBAC)

| Level | Role | Key Permissions |
|-------|------|-----------------|
| 1 | Super Admin | Full platform control, gift cards, global settings, location management override |
| 2 | Admin | Vendor verification, fraud monitoring, location data management |
| 3 | Vendor | General / Food / Digital / Service sub-types; location control for own products |
| 4 | Customer | Purchase, wallet, subscriptions, reviews, location-based browsing |
| 5 | Delivery | Logistics, delivery staff, earnings tracking |

Middleware must enforce role-based access on **both** API routes and frontend pages. Unauthorized access attempts must be logged for security monitoring. Location management endpoints must enforce **vendor-scoped access** — a vendor may only modify their own products' locations (see `verifyVendorProductOwnership` middleware pattern in Section 10).

### Mandatory fields (never allow null/empty)
- **Vendor registration:** "What are you selling?" (free text, required), Vendor Type (General/Food/Digital/Service), KYC docs (Passport/ID, Driver License, Business Registration Certificate), Food Safety Certificate (food vendors only), Default Country/Region (required for location visibility).
- **Physical products:** Name, Price, Category, Stock quantity, description, display location settings, shipping location settings, include/exclude region config.
- **Digital products:** Name, Price, File URL/License key, expiry date (if applicable), display location settings.
- **Order & checkout:** Shipping address (physical), delivery time (food), payment method (wallet or gateway), non-empty order items, customer location validated against shipping zones.
- **Payment & wallet:** every transaction links to customer wallet, vendor wallet, and escrow ledger; escrow locked until delivery confirmation.
- **Show Love:** amount > 0, recipient ID required and must be a registered user, optional message.
- **AI Search:** text/voice/image input required; voice needs mic permission; image needs upload or camera capture; results are geo-filtered by detected location.

---

## 5. Session Roadmap — 25 Sessions / 290 Steps

Each session below maps to **one Claude Pro/Code conversation**. Paste this file's relevant section + the matching spec pages at the top of each session.

### Session 1 — Full-Stack Foundation, Vertical Slice Architecture (Steps 1–5, 26–35) — App Is Live From Day One

This session absorbs all foundational work that earlier spec drafts spread across Sessions 1–4. The deliverable is not "the database is done" or "the API is done" — it's a **small, deployed, end-to-end application**: a real user can register, log in, land on a role-appropriate dashboard, and an admin/super admin can manage users, all backed by a real Postgres database, before Session 2 starts. Build the slices below **in order**; do not start a slice until the previous one is built, connected, tested, and deployed.

**Slice 1.0 — Initial Infrastructure & Configuration**
- Repo scaffolding (monorepo or `/backend` + `/frontend`), environment config (`.env` per environment), linting/formatting, base CI pipeline (install → build → test), local dev scripts (`docker-compose` for Postgres + Redis if used this early), and a deploy target (staging environment) wired up from day one.
- **Done when:** an empty "Hello, API" backend and an empty "Hello, World" frontend are both deployed to staging and reachable over the network.

**Slice 1.1 — Backend Architecture & Core API Structure**
- Express + TypeScript project structure (routes / controllers / services / repositories / middleware layers), global error handling, request validation, standard API response envelope, health-check endpoint, logging.
- **Done when:** the health-check endpoint is live on staging and returns a real response.

**Slice 1.2 — Database Setup & Migrations**
- PostgreSQL provisioning, migration tooling, seeders, and the core schema needed for everything else in this session: `users`, `roles`/`permissions`, `sessions`/`refresh_tokens`, `password_reset_tokens`, `login_activity`. (Full domain schema for payments/escrow/etc. is still built in Session 2 — this slice ships only what Session 1's slices need, additively.)
- **Done when:** migrations run cleanly against staging Postgres and are checked into version control.

**Slice 1.3 — Frontend Architecture & Shared Components/Layouts**
- Next.js (App Router) project structure, base layout, navigation shell, design tokens/theme, shared component library starting point (buttons, inputs, cards, modals, tables), API client service with auth-token handling, protected-route wrapper.
- **Done when:** the frontend is deployed to staging, shares one consistent layout, and successfully calls the Slice 1.1 health-check endpoint live (no mock data).

**Slice 1.4 — Authentication: Register, Login, Logout, Password Reset**
- Backend: registration (with role assignment), login (JWT + refresh token), logout (token invalidation), password-reset flow (request → emailed token → reset), password hashing, basic rate limiting on auth endpoints.
- Frontend: register/login/logout UI, password-reset request + reset UI, session persistence, redirect-on-auth logic.
- **Done when:** a real user can register, receive a working session, log out, and complete a password reset, end-to-end, on the deployed staging environment. Full 2FA/device-fingerprinting hardening from the original Steps 4–5 can layer on top of this slice in Session 2's security pass — this slice must ship the four flows named above (Register/Login/Logout/Password Reset) working and deployable first.

**Slice 1.5 — User Management**
- Backend: CRUD for user profiles, role assignment/change, account status (active/suspended), list/search/paginate users.
- Frontend: "My Profile" (self-service edit), and an admin-facing user list/detail/edit screen gated by role.
- **Done when:** an authenticated user can view/edit their own profile, and an admin can list, view, and edit another user's account — all through real API calls, verified against the RBAC rules in Section 4.

**Slice 1.6 — Administrator Management**
- Backend: admin-account creation/invitation, admin role tiers (Admin vs Super Admin per Section 4), permission checks enforced in middleware on every admin route.
- Frontend: admin-management screen (Super Admin only) to view/create/edit/deactivate other admins.
- **Done when:** a Super Admin can create/manage Admin accounts, an Admin cannot access Super-Admin-only actions, and unauthorized attempts are rejected and logged (per Section 4).

**Slice 1.7 — Dashboards (User, Admin, Super Admin)**
- Foundational, role-based dashboard shells — not the full feature set from later sessions, but real, live, permission-gated landing pages: User dashboard (profile summary, account status), Admin dashboard (user list, basic platform stats), Super Admin dashboard (admin management, global settings placeholder). These shells are the same components later sessions enrich (e.g. Session 2 adds escrow/wallet widgets to the existing Admin dashboard rather than building a new one).
- **Done when:** each of the three roles logs in and lands on its own correct dashboard, and role-based routing/middleware blocks cross-role access on both frontend and backend.

**Session 1 definition of done (apply after each slice above, and again for the session as a whole):**
1. Build the feature end-to-end (backend + frontend).
2. Confirm frontend, backend, and database are actually connected — no stubbed/mock responses left in place.
3. Verify authentication and role-based permissions behave correctly for every role in Section 4.
4. Run tests (unit + integration for the slice) and fix failures before moving on.
5. Deploy to staging and manually confirm the slice works before starting the next slice.

- **Critical rule:** Do not start Session 2 until all seven slices above are built, integrated, tested, and deployed. Session 2 (Payments, Escrow & Wallet) extends the already-live app — it does not wait for a separate "integration session" to make Session 1's pieces talk to each other, because they're integrated as they're built.

### Session 2 — Payments, Escrow & Wallet (Steps 6–10)
- **Steps 6–7:** Escrow system, payment protection, order settlement logic. Workflow: payment → funds held in escrow ledger → order fulfilled/confirmed → funds released (auto or manual admin override). Escrow ledger table: `order_id, amount, status`. Background jobs: escrow release scheduler, failed-delivery refund trigger.
- **Steps 8–9:** Digital wallet, double-entry ledger accounting (every transaction has credit + debit entries), immutable/tamper-proof transaction logs, transaction metadata (type, reference, timestamp, correlation ID), balance reconciliation.
- **Step 10:** Fraud detection engine — real-time fraud scoring, multi-account detection (same device/IP), gift card abuse detection, fake vendor detection, admin review queue (approve/reject/investigate).
- **Critical rule:** The Admin/Super Admin dashboard *shells* already exist and are live from Session 1 (Slice 1.7). This session's job is to extend those existing dashboards with escrow ledger views, wallet balances, and fraud-review queues — end-to-end, deployed, and tested per the Session 1 definition-of-done pattern — not to build dashboards from scratch.

### Session 3 — Core Platform Services (Steps 11–25)
- **Steps 11–15:** Subscription system (Prime-style recurring billing), review & rating system (verified-purchase validation), wishlist, affiliate/referral system, event management (ticketing). Notification queue (Redis + Bull, retry mechanism, multi-channel: email/in-app/SMS).
- **Steps 16–20:** Vendor analytics, payment gateway integrations (PayPal, Stripe, Paystack, Flutterwave, Blockonomics/Crypto), notification system, real-time chat (Socket.io, read/unread, typing indicator, file sharing, moderation), vendor live streaming ("buy during live stream", featured placement, optional recording/scheduling).
- **Steps 21–25:** Logistics & delivery (delivery wallet, proof-of-delivery image/signature, route optimization, shipping-zone validation), multi-vendor commission engine, fraud monitoring dashboard API, security enhancements (2FA, IP tracking, device fingerprint, rate limiting), search system (Elasticsearch, keyword+category+autocomplete+geo-filtering), AI voice & image search (speech-to-text, image recognition/similarity matching, search-to-recommendation pipeline).

### Session 4 — Marketplace Frontend: Storefront & Vendor Experience (Steps 26–35)
> **Note:** Under vertical slice architecture, project setup, auth UI, shared layout, and the customer/admin/super-admin dashboard *shells* originally scoped here (old Steps 26, 28, 31, 34–35) were pulled forward into **Session 1** (Slices 1.0, 1.3, 1.4, 1.7) so the app is deployable from day one. This session now covers the remaining, genuinely-Session-4-scope marketplace/vendor frontend work:
- **Steps 27, 29–30:** Marketplace homepage (Amazon-inspired, multi-homepage system with 5 templates, admin-controlled switching), product listing pages (grid/filter/sort/search/pagination/geo-filter), product detail page (gallery, reviews, recommendations, food attributes, location availability indicator).
- **Steps 31–33:** Cart & checkout UI (wallet payment, gift card input, shipping-zone validation), vendor dashboard (12 store-settings categories + location control panel) — built as a *new* dashboard extending the same role-based dashboard pattern established in Session 1, since Vendor wasn't yet in scope there.
- **Steps 34–35:** Enrich the existing Admin and Super Admin dashboards (from Session 1, Slice 1.7) with the financial-overview and location-system-controls widgets originally scoped here — same extend-don't-rebuild pattern used in Session 2.
- **Responsive grid rules (STRICT):** Mobile = 2 columns, Desktop = 4+ columns, products randomly shuffle on every reload (`ORDER BY RANDOM()` in Postgres, cached shuffle, weighted randomization boosting high-rated/high-conversion products while preserving randomness).
- **Critical rule:** Build against real APIs and real data, per the vertical-slice rule in Section 2 — no mock/static fixtures. By this session the backend from Sessions 1–3 is live, so there is no longer a reason to fake it.

### Session 5 — Specialized User Interfaces (Steps 36–51)
- **Steps 36–40:** Delivery dashboard, wallet UI, subscription UI, event pages, vendor store page. Food vendor operational system: `food_menus`, `menu_categories`, `dishes` tables; kitchen workflow (Preparing → Ready → Out for delivery), prep-time validation, delivery radius config, food-safety temperature placeholder.
- **Steps 41–45:** AI product recommendation UI ("customers also viewed", personalized, dynamic loading), live streaming UI (video player, viewer count, chat panel, menu showcase), community forum UI, affiliate dashboard UI, multi-currency & language switcher (+ location selector). Advanced AI recommendations: behavioral tracking, "frequently bought together", food-preference recs, feedback loop.
- **Steps 46–51:** SEO layer (dynamic meta tags, JSON-LD structured data, sitemap generation, SSR, canonical URLs), performance optimization (lazy loading, code splitting, skeleton loaders, Redis/CDN caching), PWA support (install banner, service worker, offline page), global notification UI, final production prep, final build/deploy command + migration guide.

### Session 6 — Administration & Vendor Tools (Steps 52–70)
- **Steps 52–61:** Advanced vendor product tools (variations, bulk CSV upload, coupons, flash sales), admin financial reporting (revenue charts, escrow ledger, payout tracking, tax reporting), platform settings management (global commission rates, subscription pricing, feature flags), global search enhancement (autocomplete, trending, history, location filter), fraud monitoring dashboard UI, system health/activity monitoring, CDN image optimization layer, email template system, deployment UI config helpers, platform completion audit (dashboard access + protected route checks). Admin action audit log (who/what/timestamp, reversible where applicable, export for compliance). Feature flag system (enable/disable without deploy, A/B testing, controlled rollout).
- **Steps 62–70:** DB optimization layer (indexing, pagination), caching strategy integration (Redis, homepage/session/location cache, invalidation patterns), background job queue UI hooks, advanced logistics tracking visualization, vendor growth tools (banner creator, promo scheduling, boost visibility), customer engagement features (personalized homepage, recently viewed, loyalty rewards), platform monetization (featured product purchase, banner ads, subscription upsell), disaster recovery prep UI, final marketplace launch readiness (nav refinement, checkout flow verification).

### Session 7 — Governance, Content & Scaling (Steps 71–89)
- **Steps 71–80:** Advanced access governance (granular role permissions, audit trails), data export & reporting (CSV, financial summaries, date range selector), vendor SLA & performance tracking, customer trust & safety (buyer protection banner, disputes, refund workflow), content moderation tools, automated growth notification campaigns, advanced analytics visualization (revenue graphs, conversion funnel, retention, **location analytics**), API usage monitoring, legal & compliance layer (privacy policy, ToS, cookie consent, GDPR data requests), ultimate marketplace completion review. Blog & content system (rich text, categories/tags, SEO per post, featured posts). Legal & compliance: GDPR-style data requests, cookie consent, ToS/Privacy acceptance tracking, vendor agreement confirmation.
- **Steps 81–89:** Real/complete DB schema (users, vendors, products, orders, escrow, wallet, subscriptions, **location tables**), wallet double-entry ledger, escrow settlement logic, high-scale microservices split (Auth, User, Product, Order, Wallet, Subscription, Notification, **Location** services), platform scaling & performance plan (sharding, read replicas, caching, async queues), security & compliance architecture (2FA, encryption, audit logging, GDPR/CCPA), production deployment architecture (Docker, CI/CD, monitoring/alerting), investor-ready technical diagram, final platform audit checklist (feature verification, API tests, penetration tests).
- **Microservices:** Auth Service, User Service, Product Service (catalog + inventory + location control), Order & Escrow Service, Wallet Service, Notification Service, **Location Service** (geo-targeting, shipping zones, Geo-IP detection, region filtering). Plus API Gateway, service-to-service comms layer, independent DBs per service.

### Session 8 — Nigerian Services & Extended Features (Steps 90–100)
- **Steps 90–95:** Chargeback & refund system (dispute management, chargeback handling), auto-delete out-of-stock products (super-admin controlled duration), Show Love system (like/follow products & vendors, monetary gifting via wallet or Paystack/Flutterwave card, optional message, notifications, `likes`/`followers`/`show_love_payments` tables), page builder (drag-drop blocks: Hero Banner, Product Grid, Testimonials, CTA Buttons, Text/Image/Video Block, FAQ Section; real-time preview; `pages`/`page_blocks`/`page_templates` tables), product groups/bundles (`product_groups`, `group_items`), abandoned cart recovery (1hr/24hr/72hr email reminders, `cart_sessions`, `email_logs`, `abandonedCartQueue`).
- **Steps 96–100:** Integrations module (Facebook Pixel, Google Tag Manager, TikTok Pixel; email marketing via Mailchimp/ConvertKit/SendPulse/MailerLite/Kartra; Telegram, Thinkific, Booking APIs). **Nigerian Service Module** (see Section 8 below for full detail). Super Admin CMS page management. System integration & finalization (wallet/analytics/RBAC wiring). Final enterprise completion review.

### Session 9 — Creator Economy (Steps 101–110)
- **Steps 101–105:** Digital creator product module (ebooks, videos, PDFs, courses; download management; license keys), creator onboarding wizard (personal info → store setup → payment setup → product upload), digital subscription system for creators (recurring billing, multiple intervals, auto-renewal, reminders, lifecycle tracking, course progress tracker), **Vendor-Controlled Affiliate & Referral Program (expanded, v4.8 — see Section 8.1 for full detail)**: what began here as auto-generated codes/click-tracking for digital products only is now the platform-wide affiliate system for **every** vendor type (General/Food/Digital/Service), with per-vendor enable/disable, per-product and per-affiliate commission rules, campaigns, an affiliate product catalog, and full attribution/lifecycle tracking through the existing Wallet/Escrow ledger — creator analytics & reports (total sales, revenue per product, subscription revenue).
- **Steps 106–110:** Frontend enhancements (digital product grid, vendor about section, social links), email/notification system for digital products (download links, subscription alerts, referral notifications), admin/super-admin enhancements (creator sales monitoring, product approval, fraud detection), background jobs & automation (auto-send download links, subscription cancellation, affiliate tracking), optional advanced features (course progress tracker, license verification, creator leaderboard).
- **Digital product protections:** secure download links with expiration, download tracking, signed URLs, access control (verified buyers only), basic anti-sharing watermarking.

### Session 10 — Vendor Location Control Module (Steps 113–120)
This is the **flagship enterprise feature of v3.0**. Full detail in Section 9 below.
- **Steps 113–116:** Location database architecture (countries/states/cities), product location association tables, location API endpoints, Geo-IP integration & customer detection.
- **Steps 117–120:** Geo-targeting/filtering engine, shipping zone system & checkout validation, vendor dashboard location controls, admin location management & overrides.

### Session 11 — Full Platform Integration (Steps 111–112) — DO NOT SKIP
- **Step 111 — Mega Prompt:** Connect all modules, connect frontend + backend, verify all APIs/services/workflows. Full requirement consolidation (see Section 11 below for the complete Mega Prompt checklist).
- **Step 112 — Ultimate Platform Completion:** End-to-end testing, cross-module testing, integration testing, workflow validation, bug fixing.
- Many platform failures happen at integration, not development. Budget real time.

### Session 12 — Production Readiness (Step 125 + Final Checklist)
- **Step 125 — Vendor Location Control Completion:** exhaustive verification checklist for the location module (database, API, Geo-IP, filtering, dashboard, shipping zones, admin controls, security, performance, backward compatibility, migration — full list in Section 12).
- Plus general production infra: monitoring, observability, disaster recovery, backups, staging environment, zero-downtime deployment.

### Session 13 — Enterprise AI, Security & Communication Platform (Steps 126–128) — v3.1 addition
Full detail in Section 18. Run this session **after** Session 12 / core platform is stable, since every sub-module here integrates with almost everything already built (RBAC, Wallet, Escrow, Fraud Detection, Notifications, Chat, AI Search, Analytics, all dashboards).
- **Step 126 — Enterprise Communication, Moderation & Customer Protection System:** banking-grade real-time messaging/voice/video across all role pairs, with AI conversation intelligence, a report/evidence-freeze pipeline, live admin intervention, and Super Admin investigation tooling.
- **Step 127 — Enterprise AI Security Operations Center (AI-SOC):** dynamic multi-agent threat detection and predictive intelligence across 27 security domains, integrated with global threat-intel feeds and automated response actions.
- **Step 128 — Enterprise SEO Intelligence & Security Configuration Center:** AI-generated SEO/structured-data automation, technical SEO tooling, search-platform integrations, and a centralized enterprise security configuration/compliance control panel.
- **Critical rule:** This session must not weaken or bypass anything already shipped — every new control is additive and must integrate with, not replace, the existing RBAC/Wallet/Escrow/Fraud/Notification/Chat/Analytics systems.

### Session 14 — Enterprise Product Catalog & Merchandising Engine (Step 129, Part IX, v3.2)
Full detail in Section 20.1. Enterprise-grade product engine (identifiers, variations, attributes, inventory, pricing, media, 360°/3D/AR, SEO, digital products, approval workflow, bulk management, search, analytics). Extends — does not replace — the existing Product Management System (Step 5) and Digital Product module (Steps 101–105).

### Session 15 — Enterprise Commerce Intelligence & Ecosystem Platform (Steps 130–143, Part X, v3.2)
Full detail in Section 20.2. Promotions/marketing engine, AI recommendations, warehouse/fulfillment, returns/disputes, subscription commerce, B2B marketplace, vendor success center, AI commerce copilots, BI/executive dashboard, workflow automation, omnichannel, headless commerce/developer platform, CMS/experience builder, localization.

### Session 16 — Enterprise Platform Services (Steps 144–153, Part XI, v3.3)
Full detail in Section 20.3. ERP integration hub, CRM/Customer 360, enterprise IAM (ABAC/PBAC/SSO/SAML/OIDC), data governance & privacy, backup/DR, observability/AIOps, AI model management (MLOps), document/DAM, unified notification center, feature management/accessibility/sustainability.

### Session 17 — Enterprise Platform Ecosystem & Extensibility (Steps 154–160, Part XII, v3.4)
Full detail in Section 20.4. App store/extension platform, theme studio/experience builder, marketplace federation (multi-marketplace ops), SaaS/tenant management, business rule engine, knowledge graph/semantic intelligence, digital twin & operations center.

### Session 18 — Enterprise Operations, Governance & Global Commerce (Steps 161–170, Part XIII, v3.5)
Full detail in Section 20.5. Tax intelligence, financial crime prevention (AML/KYC/KYB/sanctions), supply chain management, logistics network, procurement platform, government/regulated-industry edition, learning & certification, community/collaboration, data platform/analytics lake, integration gateway & operational governance (ADRs, SDL, SLOs/SLIs/SLAs).

### Session 19 — Enterprise Platform Intelligence, Governance & Experience (Steps 171–180, Part XIV, v3.6)
Full detail in Section 20.6. Search intelligence platform, consent/privacy preference center, scheduling/calendar, forms/workflow builder, secrets/key management, FinOps/cost intelligence, identity verification marketplace, trust & reputation platform, experimentation platform, metadata/governance/architecture repository.

### Session 20 — Commerce Operating System & Enterprise Intelligence (Steps 181–190, Part XV, v3.7)
Full detail in Section 20.7. AI Agent Operating System, digital identity & credential platform, enterprise asset management, contract lifecycle management, master data management, policy management, content intelligence, real-time collaboration, edge computing/offline platform, command center & global operations console.

> **Note:** Steps 191–200 (Part XVI) are not defined in any spec material provided to date — this range is a gap, not a step to skip silently. Confirm scope with the product owner before scheduling a session for it.

### Session 21 — Enterprise Engineering Blueprint & Delivery Standards (Steps 201–220, Part XVII, v4.1)
Full detail in Section 20.8. This is the first "how to build it" part rather than "what to build" — API spec repository, event catalog, database architecture, microservice architecture, reference architecture (C4/DDD/sequence diagrams), IaC, CI/CD & DevSecOps, testing framework, security engineering, AI engineering standards, UI/UX design system, documentation portal, operational runbooks, compliance mapping, performance engineering, release governance, developer experience, quality gates, support & operations, continuous improvement framework.

### Session 22 — Enterprise Delivery Framework & Reference Implementation (Steps 221–240, Part XVIII, v4.2)
Full detail in Section 20.9. Reference implementation repo, API/database/event/architecture/infrastructure/design-system/AI/security/testing repositories, DevSecOps framework, developer experience platform, documentation platform, operations framework, compliance evidence framework, performance engineering framework, release & lifecycle management, knowledge management, governance & portfolio management, continuous evolution framework.

### Session 23 — Enterprise Platform Innovation & Digital Ecosystem (Steps 241–260, Part XIX, v4.3)
Full detail in Section 20.10. Low-code/no-code platform, integration marketplace, digital twin platform, business simulation platform, innovation laboratory, ecosystem & partner platform, apps/extensions/AI-agent marketplace, organization builder, knowledge & learning platform, marketplace governance, and Steps 251–260 reserved as "future-ready platform standards" (quantum-ready crypto, tokenization, ESG, IoT — optional/governance-gated, not to be built speculatively).

### Session 24 — Enterprise Platform Governance, Global Readiness & Cross-Cutting Standards (Steps 261–270, Part XX, v4.4)
Full detail in Section 20.11. Data governance & data mesh, observability & reliability platform, accessibility & inclusive design framework, i18n/l10n, sustainability & ESG intelligence, business rules & decision management, documentation architecture (16-volume library), platform certification framework, platform maturity model (Level 1–5), platform governance charter (architecture board, AI governance council, etc).

> **Note:** Steps 271–280 (Part XXI) are not defined in any spec material provided to date — same gap-handling rule as Part XVI above.

### Session 25 — Enterprise Gift Card Generation & Management Platform (Steps 281–290, Part XXII, v4.6)
Full detail in Section 20.12. Complete gift-card lifecycle: generation engine, secure issuance/lifecycle, marketplace & distribution, wallet integration, vendor/corporate management, security/fraud/compliance, redemption & payment integration, AI gift-card intelligence, analytics & reporting, API & ecosystem integration. Explicitly designed to complement — not duplicate — the existing Wallet (Steps 8–9), Gift Card System (Step 8 original), Escrow, and Loyalty/Coupon systems.

---

## 6. Progress Tracker Template

Maintain this table in a living `SESSION_TRACKER.md` (or equivalent) and update Status + "Today's Focus" at the start/end of every session.

**Current Status:** 🔴 Not Started
**Last Updated:** _update each session_
**Today's Focus:** _set at start of session_
**Last Completed Step:** _update after each step_
**Next Step:** Step 1 — Backend Project Foundation

| Step(s) | Feature | Status |
|---|---|---|
| 1–25 | Part I: Backend Foundation | ⬜ |
| 26–51 | Part II: Frontend Development | ⬜ |
| 52–70 | Part III: Advanced Features | ⬜ |
| 71–89 | Part IV: Enterprise Architecture | ⬜ |
| 90–100 | Part V: Extended Features | ⬜ |
| 101–110 | Part VI: Digital Creator Economy | ⬜ |
| 113–120 | Part VII: Vendor Location Control Module | ⬜ |
| 111 | Mega Prompt (Integration) | ⬜ |
| 112 | Ultimate Platform Completion | ⬜ |
| 125 | Vendor Location Control Completion | ⬜ |
| 126 | Enterprise Communication, Moderation & Customer Protection System | ⬜ |
| 127 | Enterprise AI Security Operations Center (AI-SOC) | ⬜ |
| 128 | Enterprise SEO Intelligence & Security Configuration Center | ⬜ |
| 129 | Part IX: Enterprise Product Catalog & Merchandising Engine | ⬜ |
| 130–143 | Part X: Enterprise Commerce Intelligence & Ecosystem Platform | ⬜ |
| 144–153 | Part XI: Enterprise Platform Services | ⬜ |
| 154–160 | Part XII: Enterprise Platform Ecosystem & Extensibility | ⬜ |
| 161–170 | Part XIII: Enterprise Operations, Governance & Global Commerce | ⬜ |
| 171–180 | Part XIV: Enterprise Platform Intelligence, Governance & Experience | ⬜ |
| 181–190 | Part XV: Commerce Operating System & Enterprise Intelligence | ⬜ |
| 191–200 | Part XVI: **UNDEFINED — spec gap** | ⬛ N/A |
| 201–220 | Part XVII: Enterprise Engineering Blueprint & Delivery Standards | ⬜ |
| 221–240 | Part XVIII: Enterprise Delivery Framework & Reference Implementation | ⬜ |
| 241–260 | Part XIX: Enterprise Platform Innovation & Digital Ecosystem | ⬜ |
| 261–270 | Part XX: Enterprise Platform Governance, Global Readiness & Cross-Cutting Standards | ⬜ |
| 271–280 | Part XXI: **UNDEFINED — spec gap** | ⬛ N/A |
| 281–290 | Part XXII: Enterprise Gift Card Generation & Management Platform | ⬜ |

Status legend: ⬜ Not Started · 🟡 In Progress · ✅ Complete · 🔴 Blocked

---

## 7. Conventions Log (decide once, then never deviate without recording why)

> Keep appending to this section every session. Consistency prevents painful refactors.

### Naming — decisions needed
- [ ] DB column case: `snake_case` (PostgreSQL standard — recommended)
- [ ] API route style: `/api/v1/resource-name` (kebab-case — recommended)
- [ ] TypeScript interfaces: PascalCase (e.g. `UserProfile`, `VendorStore`)
- [ ] Environment variables: `SCREAMING_SNAKE_CASE` (e.g. `DATABASE_URL`)

### Database — decisions needed
- [ ] ORM/query builder: Prisma vs Drizzle vs raw `pg`
- [ ] Migration tool: Prisma Migrate vs Flyway
- [ ] UUID vs integer primary keys (UUID recommended for multi-tenant security)
- [ ] Soft delete strategy: `deleted_at TIMESTAMPTZ NULL` vs status enum

### API design (already fixed by spec — do not relitigate)
- Versioning prefix: `/api/v1/`
- Auth header: `Authorization: Bearer <token>`
- Error shape: `{ success: false, error: { code, message, details } }`
- Success shape: `{ success: true, data: {...}, meta: { pagination? } }`

### Frontend — decisions needed
- [ ] State management: Zustand vs Redux Toolkit vs React Context
- [ ] API client: Axios vs native fetch with wrappers
- Component file naming: PascalCase (e.g. `ProductCard.tsx`)
- Page file naming: Next.js App Router conventions (`page.tsx`, `layout.tsx`)

### Security — decisions needed
- [ ] Access token TTL (15 min recommended)
- [ ] Refresh token TTL (7 days recommended)
- 2FA: TOTP (Google Authenticator compatible)

### Open blockers / decisions needed from the product owner
- **Which ORM?** Prisma (easier DX) vs Drizzle (faster, more control) vs raw `pg`
- **Which state manager?** Zustand (lightweight) vs Redux Toolkit (enterprise-grade)
- **S3 or Cloudflare R2?** R2 is cheaper with no egress fees — favorable for African market traffic
- **Paystack vs Flutterwave as primary Nigerian gateway?** Both are in spec; pick one as default

### Architecture Decision Log — required format at end of every session
Every session's closing summary must document:
- Naming conventions used
- Architectural decisions made
- Libraries selected
- Design patterns implemented
- Security decisions
- Database decisions
- API standards
- Folder organization standards
- Future considerations

This log must be carried forward into all future sessions.

---

## 8. Nigerian Service Module (Steps 96–100 detail)

Full commerce layer for the Nigerian market. Architecture requirements: fully modular (each service independent), API-first, scalable, clean separation of concerns.

- **Airtime & Data:** all Nigerian networks, international top-up (170+ countries), VTU.
- **Flight Booking:** search/book/ticketing, multiple airline partners.
- **Bills Payment:** electricity (all 36 states + FCT), water (state-based), gas (cooking/natural/LPG).
- **Education:** JAMB/UTME ePIN, WAEC result checker PIN, NECO GCE pins.
- **Cable TV:** DSTV, GOTV, StarTimes, SLtv, Showmax.
- **Internet:** Spectranet, Smile, Swift, Starlink, FibreOne, IPNX, Tizeti (wifi.com.ng), Konnect Nigeria.
- **Additional services:** NIN/BVN verification, CAC registration/verification, trademark registration/check, bulk SMS, SMM services (verify/boost/like/follow/comment), withdraw-to-bank.
- **Phone number services:** virtual phone numbers (multi-country), second-number functionality, toll-free numbers, full lifecycle (activation/assignment/renewal/suspension/release).
- **VoIP (WebRTC):** in/outgoing calls, international calling, real-time call status, call logs.
- **SMS/OTP/WhatsApp/Email:** local & international SMS, OTP/2FA, WhatsApp Business API, SendGrid email.
- **eSIM & Data:** purchase/activation, QR provisioning, local/global plans, real-time usage tracking.
- **Usage monitoring:** calls/SMS/data tracking, real-time dashboard, logs/reporting.
- **Super Admin control panel:** manage API configs, per-country/service pricing, enable/disable services, monitor usage, manage users/subscriptions, view logs/transactions.
- **Required provider integrations (build an abstraction layer so providers are swappable):** Twilio (SMS/Voice/Numbers), Vonage (SMS/Voice), Airalo (eSIM/data), Truphone (eSIM).
- **Processing flow:** user selects service → payment (wallet or gateway) → external API request → async status polling → confirmation + logs.

---

## 8.1 Vendor-Controlled Affiliate Program — Full Detail (Steps 101–105 expansion, v4.8)

> Integrates into the existing Affiliate & Referral System (Steps 101–105), Vendor Dashboard, Product Management, Commission Engine (Section 16), and Wallet/Escrow ledger (Steps 8–9). **Do not create a second/parallel affiliate system** — every capability below is an extension of the Step 101–105 module, generalized from "digital products only" to all vendor types.

**Vendor affiliate controls:** enable/disable affiliate sales per store; set commission rules (vendor default, per-product, per-affiliate); select/remove affiliate-eligible products; create campaigns (name, product list, start/end dates, sales/budget limits); review affiliate performance; approve/reject applications where the program requires approval.

**Product-level affiliate settings** (product create/edit): affiliate sales enable/disable; commission type — percentage or fixed amount (₦ or $); commission amount validated against vendor-configured limits so it can never produce a negative-margin transaction.

**Affiliate product catalog** (built on the existing affiliate system, not a new one): per product — image, name, vendor, commission rate, estimated commission, price, eligibility, campaign details, link-generation action. Affiliates can search/filter by category, commission rate, vendor, location; generate/copy/share links; track clicks, conversions, commissions.

**Vendor Affiliate Dashboard** (added to the existing Vendor Dashboard): total affiliate sales, commissions paid, pending/approved/rejected commissions, top affiliates, top products, clicks, conversion rate, affiliate revenue, affiliate ROI; controls for program settings, commission settings, product eligibility, affiliate approval, campaign creation, performance/commission reports.

**Commission rule priority** (highest → lowest): Campaign-specific → Affiliate-specific → Product-specific → Vendor default → Platform default. All calculations logged with the rule applied — no silent commission math.

**Affiliate program modes:** Open (any eligible affiliate), Approval Required (affiliate applies, vendor approves), Private/Invite Only (vendor invites).

**Attribution:** link generated → clicked → product viewed → added to cart → purchase completed → order confirmed → return/refund window passes → commission payable. Requires unique affiliate IDs, unique tracking links, cookie/session + account attribution, configurable attribution windows, last-click attribution, duplicate-attribution/fraud prevention.

**Commission lifecycle:** `Pending → Order Confirmed → Holding Period → Approved → Available for Withdrawal → Paid`. On cancellation/refund/chargeback/fraud, the commission is reversed, adjusted, or held depending on transaction state — implemented via the existing Wallet ledger and Chargeback/Refund systems (Step 90), never a parallel ledger.

**Financial integration:** every commission transaction posts to the existing double-entry ledger and vendor/affiliate wallets, and records transaction ID, affiliate ID, vendor ID, product ID, order ID, amount, currency, rule used, attribution data, status, timestamp, correlation ID.

**Multi-vendor orders:** for a single order spanning multiple vendors, calculate/record each vendor's affiliate commission independently, applying each vendor's own rules with no cross-vendor bleed (reuses the existing multi-vendor cart-splitting logic in Section 16).

**Admin/Super Admin:** platform-wide affiliate policy, max commission limits, default rules, fraud monitoring, transaction visibility, dispute resolution, freezing/reversing commissions, full audit trail — vendors keep control of their own programs within these platform-wide limits.

**Analytics:** clicks, unique visitors, conversion rate, orders, gross sales, commission earned, refund rate, earnings by product/vendor/campaign/time — surfaced through the existing analytics system (Step 138 BI Dashboard) to affiliates, vendors, admins, and super admins.

---

## 9. Vendor Location Control Module (Steps 113–125) — Flagship Feature, Full Detail

**Module purpose:** each vendor independently configures (1) where products are visible/displayed, (2) where products can be shipped, and (3) automatic geo-targeted filtering that shows customers only what's available in their detected location. Granularity: Country / State-Region / City, with include/exclude logic and a worldwide toggle.

### System capabilities
- Product Display Location Control
- Product Shipping Location Control
- Customer Location Detection (Geo-IP + manual override)
- Geo-Targeted Product Filtering (auto-hide unavailable products)
- Shipping Zone Management (zone-based rules + pricing)
- Region-Based Pricing
- Admin Override Controls

### Architecture layers
| Layer | Components | Responsibility |
|---|---|---|
| Database | `countries`, `states`, `cities`, `product_display_locations`, `product_shipping_locations`, `vendor_default_locations` | Hierarchical location storage, product-location associations, vendor defaults |
| API | Location CRUD controllers, validation middleware, Geo-IP service | Location operations, hierarchical queries, location detection |
| Business Logic | Filtering engine, availability checker, shipping validator | Product visibility rules, shipping eligibility, zone matching |
| Frontend | Vendor location panel, customer location selector, admin location manager | Searchable dropdowns, AJAX loading, map integration |
| Cache | Redis location cache, product visibility cache | Sub-ms lookups, geo-filtered product sets |

### Example vendor configurations
| Vendor | Display Setting | Shipping Setting |
|---|---|---|
| A (Local Retailer) | Nigeria + Ghana only | Lagos + Abuja only |
| B (Global Brand) | Worldwide | USA + Canada only |
| C (Regional Distributor) | All of Africa except Somalia | All displayed locations + UK |
| D (City-Specific Service) | London, UK only | Local delivery within Greater London only |

### Feature 1 — Product Display Location Control
Per-product config: worldwide toggle, country/state/city multi-selects, include/exclude logic.
**Resolution priority (highest → lowest):** (1) product-level config, (2) vendor default, (3) worldwide fallback. If worldwide is ON, all rules bypassed. Include = show ONLY in listed locations. Exclude = show everywhere EXCEPT listed locations.

### Feature 2 — Product Shipping Location Control
Independent from display. Worldwide shipping toggle, country/state/city shipping zones, local-delivery-only mode, international-shipping mode. Same resolution priority pattern as display. At checkout, customer address is validated against product shipping zones; invalid items block checkout with clear messaging; cart-level validation applies.

### Feature 3 — Customer Location Filtering
**Detection priority:** (1) Geo-IP (MaxMind GeoIP2), (2) Browser Geolocation API, (3) saved customer profile location, (4) manual dropdown selection.
**Hiding logic:** a product is HIDDEN only if customer location is known AND product has restrictions AND worldwide is OFF AND (include-mode location not in allowed list OR exclude-mode location in excluded list). Otherwise SHOWN. Filtering happens at the DB query level for performance; customer can override detected location anytime.

### Feature 4 — Location Database (hierarchical, seeded from GeoNames)
Three tables: `countries` (ISO 3166 alpha-2/alpha-3, phone code, currency, region/subregion, lat/long, `enabled_for_display`, `enabled_for_shipping`), `states` (FK to country, code, name, lat/long), `cities` (FK to state + country, name, lat/long, timezone). All indexed on FK + name + active flag.

**Seeding plan:** ~249 countries (ISO 3166), ~4,000 states/provinces, ~150,000 cities (prioritized by population). Top 50 traffic countries marked `enabled_for_display = true` initially; admin-configurable gradual rollout; monthly GeoIP DB update cron.

### Feature 5 — Product Location Association Tables
- `product_display_locations` — product_id, country_id, state_id (nullable), city_id (nullable), rule_type (`include`/`exclude`), is_worldwide, created_by, timestamps. Unique on (product, country, state, city, rule_type).
- `product_shipping_locations` — same shape plus `shipping_rate`, `delivery_days_min/max`.
- `vendor_default_locations` — vendor_id (unique), array columns for default display/shipping countries/states/cities, worldwide flags, `display_rule_type`, `apply_to_all_products`.
- `shipping_zone_rates` — product_id, zone_type (local/regional/national/international), country_id, state_id, base_rate, per_kg_rate, free_shipping_threshold, delivery_days_min/max.
- `product_region_pricing` — product_id, country_id/state_id/city_id, price, compare_price, currency_code, valid_from/valid_until.

All FKs use `ON DELETE CASCADE` — deleting a product automatically cleans up every location, shipping-zone, and region-pricing row. **No FK from existing tables to these new tables** — fully decoupled, safe to drop if ever necessary.

### API surface
- **Public (no auth):** `GET /api/v1/locations/countries`, `GET /api/v1/locations/countries/:id/states`, `GET /api/v1/locations/states/:id/cities`, `GET /api/v1/locations/detect` (Geo-IP), `GET /api/v1/locations/search`.
- **Vendor (auth required, ownership-scoped):** GET/POST/DELETE `.../vendor/products/:id/display-locations` and `.../shipping-locations`; GET/PUT `.../vendor/default-locations`; POST `.../vendor/products/bulk/apply-locations`.
- **Admin/Super Admin:** POST/PUT `.../admin/countries[:id]`, `.../admin/states[:id]`, `.../admin/cities[:id]`; POST `.../admin/vendors/:id/location-override`; GET `.../admin/location-analytics`.
- **Rate limits:** public reads 100/min/IP; Geo-IP detect 30/min/IP; vendor writes 50/min/vendor; admin management 200/min/admin.

### Middleware & security
- `verifyVendorProductOwnership` — 403s any vendor trying to touch a product they don't own.
- `validateLocationIds` — validates country is active, state belongs to country, city belongs to state; rejects invalid/inactive IDs with 400.
- Rule type restricted to enum `['include','exclude']`; worldwide flag validated boolean; all queries parameterized (no SQL injection); output-encoded location names (no XSS).

### Filtering engine & search integration
- Applies at DB query level (Postgres fallback query pattern is specified in the spec PDF) and via Elasticsearch nested `display_locations`/`shipping_locations` mappings when ES is available.
- Filter integration points: homepage grid, search results, category browsing, vendor storefronts, recommendation widget, related products.
- Geo-IP resolution pipeline: detect → DB lookup (ISO code → country_id, fuzzy name match → state_id/city_id) → fallback chain (city→state→country→disable filtering) → cache in Redis 1hr TTL.
- Privacy: no PII beyond location IDs stored; IP addresses not logged/stored; browser geolocation requires explicit consent; location stored client-side (localStorage/cookie), server only sees IDs — GDPR-compliant by design.

### Caching architecture (multi-layer)
| Layer | Data | TTL |
|---|---|---|
| L1 App memory | active countries, states-by-country, first-100-cities-by-state | 5 min |
| L2 Redis | full hierarchy per country, product visibility result, Geo-IP lookup | 1hr / 10min / 1hr |
| L3 CDN | static location JSON | 24hr |

Invalidation triggers: admin disables country → clear L1+L2 for that country, recompute affected product visibility; vendor updates product locations → clear that product's visibility cache + re-index; vendor updates defaults → clear all vendor products' visibility cache + queue recompute job; Geo-IP DB update → flush all geoip cache keys.

### Region-based pricing
`product_region_pricing` resolves most-specific-match-wins: city > state > country > base price. Inactive or expired (`valid_until` past) rows ignored. Ties broken by most-recent `created_at`.

### Worldwide toggle & include/exclude semantics
Worldwide ON overrides everything (all selectors disabled/grayed in UI). Toggling OFF restores previously-saved granular rules (with confirmation dialog); toggling ON saves current granular rules to history first (with confirmation dialog).

Combined logic matrix:
```
Worldwide | Rule Type | Customer Location   | Result
ON        | any       | any                 | VISIBLE
OFF       | include   | in allowed list     | VISIBLE
OFF       | include   | NOT in list         | HIDDEN
OFF       | exclude   | in excluded list    | HIDDEN
OFF       | exclude   | NOT in list         | VISIBLE
OFF       | any       | unknown             | VISIBLE (no filtering)
```

### Migration strategy (zero downtime, fully additive)
1. **3.0.0** — create new tables only (no impact on existing data), seed location data, create indexes concurrently.
2. **3.0.1** — deploy new API endpoints alongside existing ones (additive only).
3. **3.0.2** — add frontend UI behind feature flag `location_control_v1`; gradual rollout 5% → 25% → 100%.
4. **3.0.3** — enable geo-filtering behind flag `geo_filtering_v1`; background job indexes existing products as worldwide-by-default.
5. **3.1.0** — remove feature flags, full enablement, monitor error rates/perf, rollback plan stays ready.

**Backward compatibility guarantee:** products with no location data behave exactly as before (worldwide visible/shippable); existing APIs unchanged (new data is additive/nested); existing search/checkout/customer experience unaffected unless features are explicitly enabled.

**Rollback:** flip `location_control_v1` off → UI hides, listings show everything, checkout skips validation, location API routes 404 gracefully. Tables are never dropped automatically (no data loss); investigate before re-enabling.

### Vendor dashboard UX
Desktop: two-column layout (Display | Shipping), worldwide toggle at top of each, include/exclude segmented control, searchable cascading Country→State→City dropdowns (AJAX, debounced 300ms search, virtualized list for 10,000+ cities, React Query 5-min stale time), removable chips for selections, "Apply to All Products"/"Set as Default"/"Copy from Product"/"Clear All"/"Import from CSV" bulk actions.
Mobile: accordion sections, bottom-sheet picker, full-width toggle, floating save button.

### Admin controls
Country enable/disable + custom country add + bulk region toggles; state/city CRUD + CSV bulk import + merge duplicates; vendor override actions (force worldwide, restrict to region, override shipping zones, temporarily disable location rules) — all logged with admin ID, timestamp, reason, and optional expiry; location analytics dashboard (top locations by product count, coverage %, customer distribution map, blocked-product-view counts, shipping-zone performance, vendor adoption %, Geo-IP accuracy).

### Performance targets (must be met before Step 125 sign-off)
| Endpoint | Target p95 |
|---|---|
| GET /countries | < 10ms |
| GET /states | < 15ms |
| GET /cities (paginated) | < 25ms |
| GET /locations/detect | < 50ms |
| POST /display-locations (bulk 100) | < 200ms |
| Product visibility check (cached) | < 5ms |
| Search with geo-filter | < 100ms |

Also: Geo-IP country accuracy > 95%, city accuracy > 70%; Redis cache hit rate > 80%.

---

## 10. Middleware Reference Patterns (from spec — implement faithfully)

```ts
// verifyVendorProductOwnership.ts — applied to all vendor location routes
const verifyVendorProductOwnership = async (req, res, next) => {
  const vendorId = req.user.vendor_id;
  const productId = req.params.product_id || req.body.product_id;
  const product = await db.query('SELECT vendor_id FROM products WHERE id = $1', [productId]);
  if (!product.rows[0] || product.rows[0].vendor_id !== vendorId) {
    return res.status(403).json({ success: false, message: 'You can only manage locations for your own products' });
  }
  req.product = product.rows[0];
  next();
};
```

```ts
// validateLocationIds.ts — validates country/state/city hierarchy + active status
// Rejects with 400 on: invalid/inactive country_id, state not belonging to country,
// city not belonging to state. locations payload must be an array.
```

---

## 11. Step 111 — "Mega Prompt" Consolidated Requirements

Use this as the master checklist when performing the full-platform integration pass.

**Backend must include:** modular Node/Express architecture; complete Postgres schema including location tables; JWT auth with full role hierarchy; vendor sub-types (General/Food/Digital/Service) with mandatory "What are you selling?" field; complete 12-category store settings; wallet double-entry ledger + escrow settlement; multi-gateway payments + real-time chat; Nigerian services integration; AI voice/image search; advanced fraud detection with scoring; background job queue system; full vendor location control module (display/shipping location mgmt, Geo-IP detection + filtering, region pricing, shipping zones, include/exclude + worldwide toggle, admin overrides, caching).

**Frontend must include:** responsive design (2/4+ col grid); role-based dashboard routing; drag-drop page builder; custom domain config UI; real-time order tracking + live streaming; wallet visualization; multi-homepage system (5 templates); dynamic product shuffling; full location control panel (cascading searchable dropdowns, worldwide toggle, include/exclude UI, bulk apply, AJAX + virtualization); customer location selector with Geo-IP auto-detect; shipping-zone visualization at checkout; location-based pricing display; admin location management UI; location analytics dashboard with geo-distribution maps.

**Database must include:** `users` (with vendor_type + what_are_you_selling), `vendor_store_settings` (JSON, 12 categories), `vendor_domains`, `products` (+ food_attributes), `food_menus`/`menu_categories`/`dish_variations`, `orders`/`order_items`/`escrow_ledger`/`wallet_ledger`, full location hierarchy (`countries`/`states`/`cities`), `product_display_locations`, `product_shipping_locations`, `vendor_default_locations`, `shipping_zone_rates`, `product_region_pricing`, plus all tables from Steps 81–110.

**Special features to confirm present:** Show Love (social + monetary), chargeback & refund system, auto-delete out-of-stock, page builder, product groups/bundles, abandoned cart emails, all third-party integrations, Nigerian bill-pay services, Super Admin CMS, food-vendor tools, full location control system, AJAX dynamic location loading, multi-layer caching, backward compatibility with pre-3.0 products.

## Step 112 — Ultimate Platform Completion Checklist
All 112 steps implemented · all modules integrated · all dashboards accessible by correct roles · all payment flows tested · all security measures active · scaling prep ready · food vendor workflow tested end-to-end · store settings save/load verified · custom domain routing confirmed · digital creator features operational · Nigerian services tested · AI search/recommendations functional · multi-homepage verified · audit logging active · background jobs processing.

---

## 12. Step 125 — Vendor Location Control Completion Checklist (full)

**Database:** countries seeded (249+, ISO codes) · states populated for active countries · cities populated (150,000+) · indexes verified · display/shipping location tables with correct FKs · vendor_default_locations with array fields · shipping_zone_rates · product_region_pricing · CASCADE deletes verified.

**API:** all public location endpoints paginated/working · Geo-IP detect endpoint working · cross-type search working · vendor CRUD secured with ownership middleware · admin override endpoints role-restricted · bulk apply handles 100+ products · rate limiting enforced · invalid IDs rejected.

**Geo-IP & detection:** MaxMind DB installed/current · country accuracy > 95% · city accuracy > 70% · browser geolocation w/ permission handling · manual override functional · location stored in Context + localStorage + cookie · SSR-compatible via cookie · no IP storage (privacy).

**Filtering engine:** unrestricted products always shown · include mode correct · exclude mode correct · worldwide bypass correct · unknown location = show all · DB filtering p95 < 100ms · ES geo-filter < 50ms · visibility cache hit rate > 80% · applied everywhere (homepage/search/category/storefront/recs).

**Vendor dashboard:** Location Control tab present on all product edit pages · worldwide toggle functional (display + shipping) · include/exclude control clear · cascading dropdowns AJAX (<10ms) · multi-select chips w/ remove · bulk apply from product grid · "Use Vendor Defaults" · save states (loading/success/error) · responsive on mobile/tablet/desktop · virtualized scroll for 10,000+ cities.

**Shipping zones:** config saves correctly · checkout validates address against zones · clear error on non-shippable items · cart-level validation blocks checkout · rate calculated from zone_rates · delivery estimate shown · local-only mode enforced · international mode handles customs · cart splitting accounts for per-vendor shipping availability.

**Admin controls:** country enable/disable · state/city CRUD + CSV import · vendor override API + audit log · override expiry auto-enforced · location analytics dashboard · admin can view all vendor configs · CSV export · all actions logged (who/what/when/why).

**Security:** vendors 403'd outside their own products · all location IDs DB-validated · inactive locations rejected · rate limiting active · parameterized queries throughout · XSS-safe outputs · admin overrides require admin/super_admin role · full audit metadata captured.

**Performance:** country list < 10ms, state list < 15ms, city page < 25ms (all cached) · Geo-IP detect < 50ms · visibility check < 5ms (cached) · geo-filtered search < 100ms · bulk update (100 products) < 200ms · Redis hit rate > 80% · ES geo-filter overhead < 20ms.

**Backward compatibility:** no-location products still worldwide by default · API response shape unchanged (additive nested field) · search still includes unrestricted products · checkout unchanged absent shipping restrictions · customer experience unchanged unless opted-in · third-party integrations unaffected · feature-flag rollback possible.

**Migration:** zero-downtime table creation · seed data imported successfully · concurrent index builds (no table locks) · feature flags configured for gradual rollout · rollback plan tested/documented · no data loss · ES index updated with location mappings · Redis warmed for active queries.

---

## 13. Final Platform Completion Checklist (whole project, before public launch)

- [ ] All database migrations working
- [ ] Authentication fully functional
- [ ] RBAC operational
- [ ] Escrow operational
- [ ] Wallet operational
- [ ] Accounting system balanced
- [ ] Fraud detection operational
- [ ] Notifications operational
- [ ] Chat operational
- [ ] Logistics operational
- [ ] AI search operational
- [ ] Frontend connected to backend
- [ ] Vendor systems operational
- [ ] Admin systems operational
- [ ] Analytics operational
- [ ] Content systems operational
- [ ] Nigerian services operational
- [ ] Creator economy operational
- [ ] Affiliate system operational
- [ ] Vendor location controls operational
- [ ] Integration testing passed
- [ ] Performance testing passed
- [ ] Security testing passed
- [ ] Backup and recovery tested
- [ ] Monitoring operational
- [ ] Production deployment verified
- [ ] End-to-end user journeys tested
- [ ] Platform ready for public launch

**v3.1 additions:**
- [ ] Enterprise communication (chat/voice/video) operational across all role pairs
- [ ] Customer Protection Center (report + evidence-freeze pipeline) operational
- [ ] Admin live-intervention tools (join/mute/suspend/lock) operational
- [ ] Super Admin investigation tools (silent monitor, evidence export) operational
- [ ] AI Conversation Intelligence detecting and flagging in real time
- [ ] AI-SOC multi-agent orchestration operational across all 27 security domains
- [ ] Threat-intel feed integrations connected and updating
- [ ] Automated security response actions verified safe (correctly call existing Wallet/Escrow/Vendor services)
- [ ] AI-SOC dashboard live and accurate
- [ ] AI SEO Intelligence generating meta/schema data correctly
- [ ] Technical SEO tooling (sitemaps, redirects, Core Web Vitals) operational
- [ ] Search platform integrations connected (GSC, GA4, Bing, Merchant Center, IndexNow, pixels)
- [ ] Enterprise Security Configuration Center controls verified (headers, WAF, key rotation, MFA policy, geo-blocking)
- [ ] SEO Intelligence Dashboard and Security Intelligence Dashboard live and accurate
- [ ] Confirmed v3.1 introduces no breaking changes to v3.0 modules, APIs, database structures, or microservices

**v3.2–v4.6 additions (Parts IX–XXII, Section 20):** given the size of this expansion, treat the checklist below as a gate for the *engineering blueprint and platform-services layer* rather than a single flat checklist — each line represents a whole session's worth of verification.
- [ ] Enterprise Product Catalog & Merchandising Engine operational (variations/attributes/inventory/pricing/media/360°-3D-AR/SEO/approval workflow) — Part IX
- [ ] Commerce Intelligence & Ecosystem Platform operational (promotions, AI recommendations, warehouse/fulfillment, returns, subscriptions, B2B, vendor success, AI copilots, BI, workflow automation, omnichannel, headless commerce, CMS, localization) — Part X
- [ ] Enterprise Platform Services operational (ERP hub, CRM/Customer 360, enterprise IAM, data governance, backup/DR, observability/AIOps, MLOps, DAM, unified notifications, feature mgmt/accessibility/sustainability) — Part XI
- [ ] Platform Ecosystem & Extensibility operational (app store, theme studio, marketplace federation, SaaS/tenant mgmt, business rule engine, knowledge graph, digital twin) — Part XII
- [ ] Operations, Governance & Global Commerce operational (tax engine, financial crime prevention, supply chain, logistics network, procurement, gov/regulated edition, learning platform, community, data lake, integration gateway) — Part XIII
- [ ] Platform Intelligence, Governance & Experience operational (search intelligence, consent/privacy center, scheduling, forms builder, secrets/key mgmt, FinOps, identity verification, trust/reputation, experimentation, metadata/governance repository) — Part XIV
- [ ] Commerce OS & Enterprise Intelligence operational (AI Agent OS, digital identity/credentials, EAM, CLM, MDM, policy mgmt, content intelligence, real-time collaboration, edge/offline platform, command center) — Part XV
- [ ] Part XVI (Steps 191–200) scope confirmed with product owner or explicitly deferred — currently a spec gap
- [ ] Engineering Blueprint & Delivery Standards complete (API spec repo, event catalog, DB architecture, microservice architecture, reference architecture, IaC, CI/CD, testing framework, security engineering, AI engineering standards, design system, docs portal, runbooks, compliance mapping, performance engineering, release governance, DX, quality gates) — Part XVII
- [ ] Delivery Framework & Reference Implementation repositories all populated and current (Sections 20.9 table) — Part XVIII
- [ ] Platform Innovation & Digital Ecosystem operational (low-code/no-code, integration marketplace, digital twin, business simulation, innovation lab, partner ecosystem, apps/AI-agent marketplace, org builder, learning platform) — Part XIX; Steps 251–260 confirmed still reserved/not built speculatively
- [ ] Platform Governance, Global Readiness & Cross-Cutting Standards operational (data mesh, observability/reliability, accessibility, i18n/l10n, sustainability/ESG, business rules/decision mgmt, 16-volume documentation library, certification framework, maturity model, governance charter) — Part XX
- [ ] Part XXI (Steps 271–280) scope confirmed with product owner or explicitly deferred — currently a spec gap
- [ ] Enterprise Gift Card Platform fully operational end-to-end (generation, issuance/lifecycle, distribution, wallet integration, vendor/corporate management, security/fraud/compliance, redemption, AI intelligence, analytics, API/ecosystem integration) — Part XXII
- [ ] Confirmed every Part IX–XXII module integrates with (rather than duplicates) its pre-existing counterpart — esp. AI-SOC vs AI Agent OS, Step 126 chat vs Part XV collaboration platform, and the gift card platform vs existing Wallet/Gift Card System
- [ ] Confirmed v3.2–v4.6 introduce no breaking changes to any earlier version's modules, APIs, database structures, or microservices

**v4.8 additions (Section 20.14):**
- [ ] Vendor-Controlled Affiliate Program operational for all vendor types (General/Food/Digital/Service) — Steps 101–105 expansion, Section 8.1
- [ ] Commission rule priority (campaign → affiliate → product → vendor default → platform default) enforced and logged
- [ ] Affiliate attribution + commission lifecycle (Pending → ... → Paid) posting correctly to the existing Wallet/Escrow ledger
- [ ] Global Branding Footer (`GlobalBrandingFooter`) live and correct — exact wording, dynamic year, light/dark themes — on web, iOS, Android, Windows, macOS — Step 155
- [ ] External Gift Card Payment Integration operational: merchant onboarding, sandbox/production separation, payment states, settlement, webhooks, fraud checks — Step 290 expansion
- [ ] 200 AI Customer Care Agents live, each with a fixed identity, correctly routed, transparently labeled as AI, and permission-scoped to only the data their task needs — Step 181 expansion
- [ ] Visual product discovery (image upload → similarity search → lookalike recommendations) verified against the existing vector search and product-media pipeline — no new search stack created
- [ ] Confirmed every v4.8 module integrates with (rather than duplicates) its pre-existing counterpart, per Section 20.14's merge table
- [ ] Confirmed v4.8 introduces no breaking changes to any earlier version's modules, APIs, database structures, or microservices

---

## 14. Vendor Store Settings — 12 Required Modules

Every vendor must have all 12 configured with sane defaults at account creation: Custom Domain, General Settings, Charges, Profile, Email Preferences, Currency Settings, Delivery Settings (incl. shipping location controls), Store Design, Support Channels, Legal Pages, Payout Settings, Password Management.

---

## 15. Order Status Lifecycle

`Pending → Paid → Processing → Shipped/Out for delivery → Delivered → Completed`, with side-branches to `Cancelled` and `Refunded`. Every transition needs a timestamped status-change log; admin can override status manually.

---

## 16. Supporting Infrastructure Reference (System Infrastructure & Core Services)

- **Background jobs:** escrow release, refund/chargeback processing, email (incl. abandoned cart), fraud scanning, subscription renewal, Nigerian service status polling, **product location re-indexing**, **location data sync (GeoIP updates)**, **bulk location import processing**, **visibility cache warming**. Tech: Redis+Bull/RabbitMQ, exponential backoff retry, dead-letter queue, job status dashboard.
- **Custom domain system:** connect/verify vendor domains, DNS config, routing logic.
- **Payment webhooks:** Paystack, Flutterwave, Stripe, PayPal — verify + update status + retry on failure.
- **Email infra:** provider abstraction, async queue, template rendering, bounce tracking.
- **Search integration:** Elasticsearch/Meilisearch indexing pipeline incl. location mappings, geo-boosted ranking.
- **Event tracking:** views/clicks/add-to-cart/purchases for recommendations + analytics, incl. location-aware events.
- **Rate limiting:** per-IP, per-user, anti-DDoS, API quotas (see Table 29 for location-specific limits).
- **File storage:** unified abstraction over S3/R2, signed URLs, cleanup of unused uploads.
- **Multi-vendor cart splitting:** one cart → sub-orders per vendor → separate escrow + payouts → per-product shipping-zone validation → per-sub-order shipping rate.
- **Commission engine:** real-time calc at checkout, global/category/vendor-specific rates, region-pricing-aware adjustment.
- **Refund source logic:** auto-selects escrow, vendor wallet, or gateway based on order status.
- **Feature flags:** module enable/disable, gradual rollout, third-party integration toggles. Location flags: `location_control_v1`, `geo_filtering_v1`, `geo_ip_detection_v1`, `region_pricing_v1`.
- **Session management:** refresh token rotation, expiration handling, cross-device logout invalidation, location stored in session (no PII).
- **Multi-currency:** FX rate storage (real-time or cached), backend normalization, region-pricing currency support.
- **Partial payments:** wallet+card combination, insufficient-balance handling, split payment tracking.
- **Idempotency:** keys for order creation, payments, and **bulk location updates**.
- **Maintenance mode:** platform lockdown w/ admin bypass; location data updates may proceed during maintenance.
- **Zero-downtime deploy:** rolling/blue-green, migrations before app deploy, ES index updates via background jobs.
- **Staging environment:** full replica, production-like data, location data sync between staging/prod.
- **Audit trails:** user activity (login/logout, password/profile changes, purchases, **location override selections**), vendor activity (product/price/order/settings changes, **location config changes**, **default location updates**, **bulk location events**), financial logs (wallet, escrow, payouts, refunds, chargebacks, **region-pricing adjustments**). Audit record shape: `id, user_id, role, action_type, entity_type, entity_id, metadata(JSON), ip_address, device_info, timestamp` — location changes additionally carry `location_ids, rule_type, old_values, new_values`.

---

## 18. Part VIII — Enterprise AI, Security & Communication Platform (v3.1, Steps 126–128)

> Source: v3.1 spec update, appended to v3.0 as a new enterprise section. **Fully backward-compatible** — must not break existing modules, APIs, database structures, or microservices. Integrates with: Authentication & RBAC, Customer/Vendor/Admin/Super Admin Dashboards, Wallet, Escrow, Payment Gateway Engine, Fraud Detection Engine, Notification System, Real-Time Chat, AI Search, Vendor Analytics, Marketplace Analytics, Audit Logging, Event Queue, Background Jobs, Monitoring & Observability, API Gateway, Microservices Architecture, Feature Flag System, and the existing SEO layer and Security & Compliance Architecture.

### STEP 126 — Enterprise Communication, Moderation & Customer Protection System

**Purpose:** banking-grade real-time communication between customers, vendors, delivery agents, admins, and Super Admins, with AI moderation and live administrator intervention to protect customers.

**Communication matrix (who can talk to whom):**
Customer ↔ Vendor · Customer ↔ Delivery Agent · Vendor ↔ Admin · Vendor ↔ Super Admin · Customer ↔ AI Assistant · Admin ↔ Customer · Admin ↔ Vendor · Super Admin ↔ Anyone.

**Instant messaging support:** text, emoji, GIF, voice notes, images, videos, documents, PDF, product cards, order cards, payment requests, location sharing, contact sharing, polls, scheduled messages.

**Voice calling features:** WebRTC, HD voice, call waiting, hold, mute, speaker, noise cancellation, echo reduction, call transfer, call recording, AI voice enhancement.

**Video calling features:** HD video, Full HD, group calls, screen sharing, live captions, virtual background, AI noise suppression, camera switching, session recording.

**Customer Protection Center** — every conversation includes a "Report Conversation" action.
Report reasons: Scam, Fake Product, Fake Payment, Fraud, Abuse, Harassment, Copyright, Spam, Threat, Hate Speech, Child Safety, Other.

**Live Moderator System** — when a report is submitted, the system automatically:
- Freezes message deletion
- Preserves evidence, attachments, images, videos, voice notes, call recordings
- Stores timestamps, IP addresses, device fingerprints, login session
- Increases fraud score

**Admin intervention** — an admin may: join chat, join voice call, join video call, moderate discussion, send warning, remove participant, mute participant, lock conversation, suspend account, request identity verification, request KYC, escalate to Super Admin.

**Super Admin investigation** — a super admin may: silently monitor conversations, join anonymously, download complete evidence, export conversations/recordings/attachments, assign investigators, freeze wallets, freeze escrow, suspend vendors, suspend customers, view audit history.

**AI Conversation Intelligence** — AI continuously detects: scam attempts, fake payment proof, fraud, phishing, social engineering, money-laundering indicators, offensive language, spam, threats, fake identity, suspicious links. On detection, AI automatically: warns participants, creates an investigation case, alerts administrators, updates fraud score, flags suspicious conversations.

**Database tables (Step 126):** `conversations`, `conversation_members`, `messages`, `attachments`, `voice_calls`, `video_calls`, `call_recordings`, `conversation_reports`, `moderator_actions`, `investigation_cases`, `chat_audit_logs`.

**Build notes:**
- This extends (does not replace) the existing Real-Time Chat System (Step 19) and Chat System Enhancements from Part I — reuse the Socket.io infrastructure and read/unread/typing-indicator groundwork already built there.
- The evidence-freeze pipeline must integrate with the existing Fraud Detection Module (Step 10 / Steps 23, 56) — reported conversations should feed the same fraud-score mechanism, not a parallel one.
- Wallet/escrow freeze actions triggered from a conversation report must go through the existing Wallet and Escrow services (Steps 6–9, 82–83), not a new ad-hoc mechanism.
- All admin/super-admin actions here (join, mute, suspend, freeze, export) must be written to `moderator_actions` / `chat_audit_logs` **and** to the platform's existing `audit_logs` table (Section 16) so there is one unified audit trail, not two.

---

### STEP 127 — Enterprise AI Security Operations Center (AI-SOC)

**Purpose:** transform WINDELS into a banking-grade AI-secured platform using a **scalable, dynamic multi-agent architecture** — specialized AI agents are spun up on demand to analyze, predict, and respond to threats in real time, rather than maintaining a fixed pool of always-on agents (spec explicitly frames this as "instead of maintaining 20,000 fixed AI agents").

**AI Security Domains (27):** Identity Intelligence, Authentication Intelligence, Behavior Intelligence, Fraud Intelligence, Wallet Intelligence, Escrow Intelligence, Payment Intelligence, Vendor Intelligence, Customer Intelligence, Device Intelligence, API Intelligence, Database Intelligence, Cloud Security, Container Security, Kubernetes Security, Email Security, DNS Security, Certificate Intelligence, Bot Detection, DDoS Detection, Malware Detection, Ransomware Detection, Supply Chain Security, Insider Threat Detection, Network Intelligence, Mobile Security, Application Security, Compliance Intelligence.

**Global threat intelligence feeds to integrate:** MITRE ATT&CK, CVE/NVD, CISA Advisories, AbuseIPDB, AlienVault OTX, OpenPhish, Spamhaus, VirusTotal (subject to licensing), and commercial threat-intelligence providers.

**AI threat detection targets:** credential stuffing, brute force, account takeover, session hijacking, API abuse, wallet fraud, escrow fraud, payment abuse, fake vendors, fake customers, money-laundering indicators, automated bots, suspicious device activity.

**Predictive intelligence outputs:** attack probability, risk score, confidence score, threat severity, business impact, recommended response, expected attack timeline.

**Automated security response** — AI may autonomously: block IP, lock account, require MFA, disable session, freeze wallet, freeze escrow, suspend vendor, suspend customer, disable API key, alert administrators, open investigation, generate compliance report.

**Enterprise AI-SOC Dashboard displays:** live security events, threat timeline, global threat map, fraud dashboard, device risk, vendor risk, customer risk, wallet risk, escrow risk, API risk, authentication risk, compliance status, AI recommendations.

**Database tables (Step 127):** `security_events`, `security_agents`, `threat_feeds`, `attack_predictions`, `incident_cases`, `behavior_profiles`, `device_profiles`, `risk_scores`, `security_reports`.

**Build notes:**
- This supersedes and absorbs (does not duplicate) the existing "Advanced Fraud Detection & Scoring System" (Step 10), "Security System Enhancements" (Step 24), and "Security & Compliance Architecture" (Step 86) — AI-SOC should sit as a superset layer that consumes signals from those systems, not a competing fraud engine. Reconcile fraud-score writes to a single source of truth.
- Automated response actions (freeze wallet/escrow, suspend vendor/customer) must call the same Wallet/Escrow/Vendor services already built — never write directly to their tables.
- Because agents are created dynamically, design the `security_agents` table and orchestration layer to track agent lifecycle (spawned, active domain, last action, retired) rather than assuming a static roster.

---

### STEP 128 — Enterprise SEO Intelligence & Security Configuration Center

**Purpose:** expand the existing SEO Optimization Layer (Step 46, "Structured Data & Indexing") into a centralized enterprise SEO **and** security management platform.

**AI SEO Intelligence — auto-generates:** meta titles, meta descriptions, canonical URLs, product keywords, long-tail keywords, Open Graph tags, Twitter Cards, structured data / JSON-LD, and schema types: Product, Review, FAQ, Breadcrumb, Article, Event, Organization, Video.

**AI Content Optimization — analyzes:** duplicate content, keyword density, readability, internal linking, external linking, search intent, competitor keywords, ranking opportunities. **Provides:** SEO score, AI recommendations, optimization suggestions, content health report.

**Technical SEO support:** XML sitemap, image sitemap, video sitemap, news sitemap, robots.txt manager, redirect manager, canonical manager, broken-link monitor, crawl-budget control, Core Web Vitals, page-speed monitoring, CDN optimization.

**Search platform integrations:** Google Search Console, Google Analytics 4, Bing Webmaster Tools, Google Merchant Center, IndexNow, Meta Pixel, TikTok Pixel, LinkedIn Insight Tag, Pinterest Tag.

**Enterprise Security Configuration Center — global controls:** Security headers (CSP, HSTS, X-Frame-Options, X-Content-Type-Options), Web Application Firewall (WAF), rate-limiting policies, API key management, OAuth provider configuration, JWT secret rotation, encryption key rotation, secrets vault integration, password policies, MFA policies, trusted device management, trusted IP management, geo-blocking rules, audit log retention, backup policies, disaster recovery settings, maintenance mode controls, feature flag security, alert notification channels, GDPR configuration, PCI DSS controls, SOC 2 controls, ISO 27001 controls.

**Enterprise dashboards:**
- **SEO Intelligence Dashboard:** SEO health score, indexed pages, sitemap status, crawl errors, broken links, keyword rankings, organic traffic, Core Web Vitals, AI SEO recommendations, Search Console insights.
- **Security Intelligence Dashboard:** overall security score, active threats, live security events, login anomalies, API health, certificate status, vulnerability summary, compliance status, secrets rotation status, AI security recommendations.

**Build notes:**
- Treat this as an **extension** of the Step 46 SEO layer, not a rebuild — reuse existing meta-tag/sitemap/JSON-LD infrastructure and layer AI generation + the new dashboards on top.
- Security Configuration Center controls (WAF, rate limiting, JWT/encryption key rotation, MFA policy, geo-blocking, etc.) must be exposed through the existing Feature Flag System and Super Admin Dashboard, and every change must be written to the platform's existing `audit_logs` table.
- Geo-blocking rules should reuse the Vendor Location Control Module's country/state data (Section 9) rather than introducing a second geography table.
- PCI DSS / SOC 2 / ISO 27001 "controls" here are configuration toggles and reporting surfaces, not a claim of certification — do not present them to users as a certification the platform has actually achieved unless that's independently true.

---

### Part VIII Integration Requirements (must-hold invariants)

The v3.1 modules must integrate with — not duplicate or bypass — all of the following, per the spec:
Authentication & RBAC · Customer Dashboard · Vendor Dashboard · Admin Dashboard · Super Admin Dashboard · Wallet System · Escrow System · Payment Gateway Engine · Fraud Detection Engine · Notification System · Real-Time Chat System · AI Search · Vendor Analytics · Marketplace Analytics · Audit Logging · Event Queue System · Background Jobs · Monitoring & Observability · API Gateway · Microservices Architecture · Feature Flag System · existing SEO Optimization Layer · existing Security & Compliance Architecture.

**Backward compatibility guarantee (explicit in spec):** v3.1 must not break existing modules, APIs, database structures, or microservices from v3.0. Apply the same additive-migration discipline used for the Location Control Module (Section 9 → "Migration Strategy & Backward Compatibility"): new tables only, new endpoints only, feature-flagged rollout, documented rollback.

---

## 20. Parts IX–XXII — Enterprise Platform Expansion (v3.2 → v4.6, Steps 129–290)

> This section condenses a very large body of spec material (Steps 129–290 across 12 defined Parts, spanning spec versions v3.2 through v4.6). Each subsection lists what the Part covers; treat bullet groups as capability checklists to implement against, not literal prose to copy. Two step ranges (Part XVI, Steps 191–200; Part XXI, Steps 271–280) were never supplied in any spec material received — they are **gaps**, not silently-skippable ranges. Every Part in this section is explicitly additive/backward-compatible with everything before it, per the source spec.

### ⚠️ Feature-Freeze Recommendations (carried over verbatim in spirit from the source)
The source material itself repeatedly recommended stopping feature expansion and shifting to implementation — at v3.5 ("should now be treated as the baseline for implementation"), v3.6, v4.1 ("I recommend freezing the functional specification"), and v4.3 ("I recommend treating v4.3 as the feature-freeze milestone") — and then more functional Parts were added anyway each time. **Before adding any further Part beyond XXII, or building out a "gap" Part (XVI/XXI), confirm with the product owner that it's actually needed.** Don't assume the spec should keep growing just because it has so far.

Between v3.5 and v3.6 the source also proposed (as advisory content, not a numbered Part) a set of **"Enterprise Engineering Specifications"** documents: API Specification, Event Catalog, Complete Database Design, Microservice Boundary Specification, Deployment Architecture, Infrastructure as Code, Security Architecture, AI Architecture, Mobile Architecture, Testing Standards, UI/UX Design System, and an AI Agent Framework. This advisory list was later formalized into actual numbered steps in Parts XVII–XVIII (Sections 20.8–20.9 below) — so it's fully covered, just delivered two versions later than first suggested.

---

### 20.1 — Part IX: Enterprise Product Catalog & Merchandising Engine (Step 129, v3.2)

**Purpose:** a world-class product engine covering physical, digital, service, booking, subscription, rental, auction, wholesale, B2B/B2C/C2C products — extends (does not replace) the existing Product Management System (Step 5).

- **Product information:** name/descriptions/rich text, SKU/GTIN/UPC/EAN/ISBN/MPN, barcode/QR, brand/manufacturer/model, tags/collections, type/status/visibility/priority, rating/reviews/Q&A, warranty, condition, country of origin, vendor info.
- **Categories:** unlimited nested categories/trees, icons/images, SEO, featured, ordering.
- **Variations:** unlimited axes (color, size, material, storage, RAM, weight, style, flavor, capacity, dimensions, finish, gender, region, bundle, custom); each variation carries its own SKU/barcode/quantity/weight/price/sale price/cost/media/360°/availability/status.
- **Attributes:** unlimited (brand, material, fabric, processor, display, battery, voltage, ingredients, compatibility, features, specs).
- **Inventory engine:** quantity/reserved/available/incoming/warehouse/store/vendor/damaged/returned/safety/min/max/low-stock/restock thresholds; FIFO/LIFO, batch/lot tracking, serial numbers, expiration dates.
- **Pricing engine:** regular/sale/cost/wholesale/distributor/VIP/member/country/currency/tier pricing, quantity discounts, dynamic & scheduled pricing.
- **Media management:** unlimited images/video/audio/docs/PDFs/manuals; compression, optimization, AI background removal/enhancement, watermarks, auto-resize, multi-format, CDN delivery.
- **360°/3D/AR:** 360° viewer (drag/touch/mouse/gesture rotate, auto-spin, zoom, pan, full-screen, hotspots); 3D viewer (glTF/GLB/USDZ/OBJ/FBX, lighting/shadows/reflection, exploded views, AR-ready); AR (view in room/on table/on body/in space, QR launch, Apple Quick Look, Android Scene Viewer); AI product visualization (lifestyle images, background/room/furniture placement, fashion try-on, mockups, marketing banners). Vendors may upload standard images, 360° image sets, interactive spin images, or full 3D models directly; supported upload formats: JPG, PNG, WebP, GLB, GLTF, USDZ, OBJ, FBX.
  - **AI 360 Capture Assistant (v4.7 merge):** a phone-camera-only guided capture flow so vendors don't need a turntable or studio. The app walks the seller through the minimum six capture positions (front, back, left, right, top, bottom) plus optional intermediate angles (front-left, front-right, rear-left, rear-right) for a smoother reconstruction. On upload, the pipeline automatically removes backgrounds, aligns frames, corrects perspective, balances lighting, stitches the interactive 360° object, generates optimized web assets, and produces a preview thumbnail — all as an extension of the existing AI background-removal/enhancement media pipeline above, not a separate system.
  - **AI 3D Reconstruction (v4.7 merge):** once enough capture-assistant photos exist for a product, the same pipeline can automatically reconstruct a lightweight 3D model (GLB/GLTF output), with mesh/texture optimization for web and mobile — feeding directly into the 3D viewer described above.
- **Product SEO:** auto-generated SEO title/description/slug/canonical, OG/Twitter cards, Product/Review/FAQ schema, rich snippets, AI keyword suggestions.
- **Shipping:** weight/dimensions, shipping classes/zones, package types, delivery time, hazmat, temperature-sensitive, shipping restrictions.
- **Digital products:** downloads, license keys, activation codes, software, ebooks, video/audio, templates, source code, digital art.
- **Approval workflow:** `Draft → Pending Review → Approved → Published → Featured → Archived / Rejected`, admin/super-admin approve/reject with comments and audit history.
- **Bulk management:** CSV/Excel import, bulk export/edit/delete/category-assign/price-update/inventory-update/image-upload.
- **Enterprise search:** by name/SKU/barcode/brand/category/vendor/attribute/variation/tags/location/price/rating/availability.
- **Product analytics:** views/clicks/favorites/add-to-cart rate/conversion rate/sales/revenue/inventory turnover/best sellers/trending/AI recommendations.

**Database tables:** `product_brands`, `product_brand_categories`, `product_tags`, `product_tag_map`, `product_attributes`, `product_attribute_values`, `product_variations`, `product_variation_options`, `product_inventory`, `product_inventory_transactions`, `product_serial_numbers`, `product_batches`, `product_media`, `product_videos`, `product_documents`, `product_360_images`, `product_3d_models`, `product_ar_assets`, `product_shipping_profiles`, `product_shipping_rules`, `product_seo`, `product_price_history`, `product_pricing_rules`, `product_discount_rules`, `product_collections`, `product_favorites`, `product_compare`, `product_questions`, `product_answers`, `product_views`, `product_analytics`, `product_search_index`, `product_ai_assets`, `product_status_history`, `product_360_capture_sessions` (v4.7 — tracks the AI 360 Capture Assistant's per-product capture positions, processing status, and generated asset references).

**Event Ticket Media (v4.7 merge — extends the Event Management System, Step 15, not a new system):** event organizers get the same media stack as products — images, videos, interactive 360° media, 3D objects, venue walkthroughs, interactive seating previews, stage previews, booth previews, and exhibition layouts — attached to ticket/event pages via the same `product_media`/`product_360_images`/`product_3d_models`-style tables (event rows reuse the product-media schema rather than a parallel one). Ticket pages render this through the identical 360°/3D viewer component used on product detail pages.

**Integrates with:** Marketplace Engine, Multi-Vendor System, Wallet, Escrow, Orders, Checkout, Inventory/Warehouse Management, Shipping Providers, Location Control Module, AI Search, AI Recommendation Engine, SEO Intelligence Center, AI-SOC, Notifications, Analytics, Audit Logging, Digital Creator Platform, Subscription Engine, Booking/Auction Engine, Wholesale/B2B Module, Event Management System (Step 15), Mobile Apps, all dashboards.

---

### 20.2 — Part X: Enterprise Commerce Intelligence & Ecosystem Platform (Steps 130–143, v3.2)

| Step | Module | Key capabilities |
|---|---|---|
| 130 | Promotion & Marketing Engine | % / fixed / BOGO / mix-match / bundle / volume / tiered / category / brand / vendor / customer-group discounts; flash sales; happy hour; holiday/birthday/anniversary/first-purchase/referral/cashback/free-shipping/free-gift campaigns. AI recommends promos, predicts performance, suggests discount %, detects coupon abuse, calculates ROI. |
| 131 | AI Recommendation Engine | "Recommended for you", similar products, frequently bought together, trending near you, recently viewed, new arrivals, AI shopping assistant. Vendor-side: pricing/inventory/bundling/cross-sell/upsell/SEO/forecast recommendations. |
| 132 | Warehouse & Fulfillment Management | Multi-warehouse/regions, transfers, pick/pack lists, shipping labels, staff/roles, bin/shelf locations, forecasting, batch/serial tracking, QC, returns processing. |
| 133 | Returns, Refunds & Dispute Resolution | RMA, exchanges, partial/full refunds, return labels/tracking, inspection workflow, buyer/seller disputes, admin mediation, AI dispute assistant, evidence upload, escalation, audit history. |
| 134 | Subscription Commerce Engine | Weekly/monthly/quarterly/annual/custom billing, trials, subscription boxes, membership products; pause/resume/upgrade/downgrade, auto-renewal, billing retry, failed-payment recovery, usage-based billing, analytics. |
| 135 | B2B Marketplace | Company accounts/teams/departments, POs, RFQs, quote negotiation, contract pricing, credit limits, Net 30/60/90 terms, business catalogs, approval workflows, procurement dashboard. |
| 136 | Vendor Success Center | Vendor CRM, performance dashboard, health score, AI business coach, learning center, certification, SLA monitoring, revenue analytics, satisfaction metrics, benchmarking. |
| 137 | AI Commerce Copilot | Customer AI (shopping assistant, product discovery, gift finder, size/fit advisor, order/return assistant); Vendor AI (product writer, SEO optimizer, pricing/inventory advisor, marketing/support assistant); Admin AI (executive reports, fraud summaries, security insights, compliance assistant). |
| 138 | BI & Executive Dashboard | Revenue forecasting, profit analysis, CLV, churn prediction, vendor profitability/health scoring, inventory & sales forecasting, marketplace health score, sales heatmaps, regional/geo analytics, fraud analytics, operational KPIs, AI executive summaries, board-level reports, **scheduled daily/weekly/monthly report generation and delivery (v4.7 merge)**. |
| 139 | Workflow Automation Platform | Visual drag-and-drop, **BPMN-inspired** workflow engine (v4.7 merge — the spec's BPMN-inspired framing is folded into the existing no-code builder rather than kept as a separate engine): conditional logic, event-driven automation, AI decision nodes, human approval nodes, timers, scheduled jobs, retries with exponential backoff, rollback, versioning, and full audit logging of every run. Exposes workflow-trigger and workflow-status **APIs** for external systems. Reference example workflows (v4.7 merge — documented patterns, not new steps): **Vendor Registration** (Registration → KYC → AI Verification → Admin Review → Store Creation → Welcome Email); **Commerce** (Order → Inventory → Escrow → Shipping → Notifications → Analytics); **Fraud** (Fraud Detection → Freeze Wallet → Lock Account → Notify Super Admin → Investigation Case → Resolution) — this fraud workflow orchestrates the existing Fraud Detection engine (Step 10) and AI-SOC (Step 127), it does not replace them. |
| 140 | Omnichannel Commerce Platform | Facebook/Instagram/TikTok Shop, WhatsApp Business, POS, mobile/web, marketplace APIs, social/live/QR commerce — centralized inventory, pricing, order sync, customer mgmt, analytics across channels. |
| 141 | Headless Commerce & Developer Platform | REST/GraphQL APIs, webhooks, OAuth apps, API keys, SDKs (JS/TS/PHP/Python/Java/.NET), **CLI (v4.7 merge — added alongside the existing SDK list)**, plugin/theme framework, event bus, extension marketplace, developer portal, documentation, sandbox, API analytics/rate limiting, integration marketplace, versioning. |
| 142 | Enterprise CMS & Experience Builder | No-code drag-drop builder for landing pages, blog, help center, FAQ, knowledge base, dynamic content, forms/popups/banners, email template builder, content scheduling, personalization, A/B testing. |
| 143 | Localization & Global Commerce | Unlimited languages + RTL, multi-currency, FX management, regional pricing/catalogs, tax jurisdictions, time zones, local holidays, localization AI, country restrictions, international shipping, local payment methods. |

**Integrates with:** Marketplace/Product Catalog Engines, Wallet, Escrow, Orders, Checkout, Payments, Inventory, Warehouse, Shipping, all dashboards, AI Search/Recommendation/AI-SOC, SEO Intelligence Center, Notification Center, Analytics, Audit Logging, Workflow Automation, Mobile Apps, API Gateway, Event Bus, Microservices Architecture.

---

### 20.3 — Part XI: Enterprise Platform Services (Steps 144–153, v3.3)

| Step | Module | Key capabilities |
|---|---|---|
| 144 | ERP Integration Hub | POs, procurement, inventory/warehouse sync, manufacturing/production planning, financial accounting (AR/AP/GL/cost centers/fixed assets/budget/tax), HR/payroll sync, supplier mgmt. Integration framework: REST/SOAP/GraphQL, webhooks, scheduled/event-based sync, retry policies, conflict resolution, mapping rules, validation. |
| 145 | CRM & Customer 360 Platform | Tracks purchase/browsing/wishlist/cart history, communication timeline, support tickets, refunds/returns, loyalty/rewards, LTV, churn risk, segments, campaign history, preferred channels, AI customer score. AI CRM: auto-segments, predicts churn, suggests campaigns/offers, identifies upsell, generates insights. |
| 146 | Enterprise IAM | Extends RBAC into RBAC + ABAC + PBAC, MFA, SSO, SAML 2.0, OIDC, OAuth 2.0, identity federation, temporary/approval-based privilege elevation, device trust, session mgmt, risk-based/adaptive authentication. |
| 147 | Data Governance & Privacy | Data catalog/classification/lineage, retention policies, consent mgmt, privacy dashboard, data residency, masking/anonymization, right to access/delete/portability, data quality monitoring, compliance reporting (GDPR/CCPA/LGPD/etc). |
| 148 | Backup & Disaster Recovery | Automated/incremental/full backups, PITR, snapshots, cross-region replication, backup encryption/verification, recovery testing; RPO/RTO targets, failover/failback, DR drills, HA, multi-region recovery, incident playbooks. |
| 149 | Observability & Monitoring Platform | Centralized logging, metrics, distributed tracing, service dependency maps, health checks, perf monitoring, error tracking, RUM, synthetic monitoring, infra/DB/queue/API monitoring. AIOps: anomaly detection, failure prediction, incident correlation, remediation suggestions, alert prioritization. |
| 150 | AI Model Management (MLOps) | Model/prompt registry & versioning, training metadata, eval metrics, deployment pipelines, rollback, drift detection, guardrails, human review, cost tracking, AI audit logs, explainability reports. |
| 151 | Document & Digital Asset Management | Contracts, invoices, KYC docs, certificates, reports, policies, manuals, legal docs; version control, OCR, AI classification/extraction, full-text search, watermarking, digital signatures, approval workflow, retention, secure sharing, access logs. |
| 152 | Unified Notification Center (doubles as the Global Communication Hub, v4.7 merge) | Channels: in-app, push, email, SMS, WhatsApp, voice, web push, Slack, Teams, webhooks. Features: inbox, read status, delivery tracking, retry, scheduling, templates, user preferences, quiet hours, priority levels, AI optimization. **v4.7 addition merged in rather than duplicated:** every conversation across every channel above is attached to its owning entity — Customer, Vendor, Order, Ticket, Case, or Workflow — and surfaced as one unified communication timeline per entity, reusing the communication-timeline field already defined on CRM & Customer 360 (Step 145) rather than a new timeline model. Live messaging/voice/video itself remains owned by Step 126 (customer-facing) and Step 188 (internal collaboration); this step is the delivery/inbox/timeline layer over both. |
| 153 | Feature Management, Accessibility & Sustainability | Feature flags, canary/blue-green/percentage rollouts, tenant-specific features, kill switches, A/B testing. Accessibility: WCAG 2.2 AA (screen reader, keyboard nav, high contrast, reduced motion, captions, focus mgmt, accessible forms/charts/tables, audits). Sustainability: carbon footprint, sustainable packaging/green shipping, energy consumption, ESG metrics/reports/KPIs. |

**Non-functional requirements (apply to Parts I–XI as a whole):** horizontal scalability, HA, auto-scaling, low-latency APIs, efficient caching, DB partitioning · Zero Trust, E2E/at-rest/in-transit encryption, secrets mgmt, continuous vulnerability scanning, dependency checks · idempotent ops, retries, circuit breakers, DLQs, graceful degradation, automated recovery · PCI DSS/GDPR/CCPA/SOC 2/ISO 27001/regional compliance · comprehensive testing, API versioning, backward compatibility, complete docs, OpenAPI specs, additive-only migrations.

---

### 20.4 — Part XII: Enterprise Platform Ecosystem & Extensibility (Steps 154–160, v3.4)

- **154 — Marketplace App Store & Extension Platform (confirmed as the full Marketplace App Store, v4.7 — no changes needed):** app types (marketplace/payment/shipping/ERP/CRM/marketing/AI/analytics/security/tax/identity/vendor/customer/mobile/internal apps); SDKs (JS/TS/REST/GraphQL/mobile/CLI/event/webhook); app lifecycle (registration, verification, security review, digital signing, versioning, auto-update, rollback, compatibility validation, permissions, usage analytics, billing); enterprise app marketplace (public/private/paid/free/subscription/one-time/trial apps, ratings, featured, AI recommendations, approval process, revenue sharing via Step 157's billing engine). This already covers ERP/CRM/accounting/marketing/shipping/tax/payments/logistics/analytics installable apps end to end — the v4.7 App Store request needed no new content here.
- **155 — Theme Studio & Experience Builder (confirmed as the White-Label Enterprise Platform's UI layer, v4.7 — no changes needed; v4.8 adds one shared component):** drag-drop theme builder, live preview, component library, global styles/variables, dark/light mode, responsive layouts; visual designers for homepage/landing/storefront/checkout/product/category/dashboard/email/invoice/receipt/certificate; white-label (branding, custom domain, logos/fonts/colors/icons, splash screens, feature toggles surfaced via the Feature Management system at Step 153). Paired with Step 157 below for the tenant/billing side, this already covers the full White-Label Enterprise Platform request — languages/currencies/payment gateways are handled by Localization (Step 143) and Payment Gateway Integrations (Step 17). **v4.8 addition — Global Branding Footer component:** a single reusable component (e.g. `GlobalBrandingFooter`, name to match project conventions) built on this step's existing component library and design tokens — not a new design system. Fixed content: left `"Proudly Powered by WIL.®"`, right `"© [CURRENT YEAR] WINDELS GROUP"` with the year computed dynamically (never hardcoded). Horizontal two-sided layout on web/Windows/macOS; horizontal-or-stacked (powered-by line, then copyright line) on iOS/Android depending on available width. Must render correctly in light/dark/system theme and any existing theme variant, across small/large phones, tablets, and desktop/resizable windows. Reused wherever a footer is appropriate across web, iOS, Android, Windows, and macOS builds — implemented once here, not once per platform.
- **156 — Marketplace Federation & Global Operations:** one org operating multiple independent marketplaces — global control center; regional/country/brand/industry/franchise/government marketplaces; shared services (auth, wallet, payments, AI, analytics, notifications, vendors, customers) vs marketplace isolation (independent catalogs, policies, taxes, pricing, branding, languages, compliance).
- **157 — SaaS & Tenant Management Platform (confirmed, v4.7 — no changes needed):** tenant provisioning/isolation/branding/domains/billing/usage/backups/analytics/lifecycle/migration; subscription plans (Free/Starter/Professional/Enterprise/Government/Custom); billing (usage-based, seat licensing, API/storage/AI-consumption billing, marketplace revenue sharing). Together with Step 155, this already delivers multi-tenant architecture, licensing, and subscription plans as requested for the White-Label Enterprise Platform.
- **158 — Business Rule Engine:** visual rule builder, conditional/nested logic, expressions/variables, AI rule suggestions, testing sandbox, rule versioning; rule categories (payments, orders, shipping, marketplace, promotions, fraud, KYC, compliance, inventory, vendor approval, customer eligibility, returns, notifications, taxes); rule actions (approve/reject/escalate/notify/freeze/retry/route/calculate/schedule/execute workflow).
- **159 — Knowledge Graph & Semantic Intelligence:** models relationships between products/vendors/customers/orders/categories/brands/locations/warehouses/campaigns/payments/security events/AI models/documents; semantic search (NL search, intent recognition, context awareness, relationship/similarity search); AI intelligence (knowledge retrieval, context-aware responses, recommendation reasoning, fraud pattern discovery, relationship analysis).
- **160 — Digital Twin & Operations Center:** real-time visualization of marketplaces/warehouses/orders/inventory/vendors/customers/deliveries/payments/wallets/escrow/AI systems/security events/infrastructure/APIs/DBs; operational intelligence (live status, health monitoring, capacity planning, predictive maintenance, incident visualization, resource utilization, performance forecasting, AI operational insights).

**Database tables:** `app_store_apps`, `app_store_versions`, `app_permissions`, `app_installations`, `app_reviews`, `developer_accounts`, `developer_organizations`, `theme_packages`, `theme_assets`, `theme_templates`, `marketplaces`, `marketplace_regions`, `marketplace_settings`, `tenants`, `tenant_subscriptions`, `tenant_usage`, `tenant_billing`, `business_rules`, `business_rule_versions`, `business_rule_executions`, `knowledge_graph_nodes`, `knowledge_graph_edges`, `semantic_embeddings`, `semantic_search_index`, `digital_twin_assets`, `digital_twin_events`, `digital_twin_metrics`, `platform_extensions`, `platform_plugins`, `plugin_permissions`.

**Architecture principles required here:** API-first, event-driven, DDD, Clean Architecture, CQRS where appropriate, Saga pattern for distributed transactions, idempotent ops, Zero Trust, multi-region support, horizontal scalability, additive migrations, IaC, comprehensive testing, OpenTelemetry observability, AI governance/auditability.

---

### 20.5 — Part XIII: Enterprise Operations, Governance & Global Commerce (Steps 161–170, v3.5)

- **161 — Tax Intelligence & Compliance Engine:** VAT/GST/sales/digital-services/excise/customs/import/export/withholding/marketplace-facilitator tax; multi-country rules, jurisdictions, exemptions, reverse charge, inclusive/exclusive pricing, auto-calculation, tax invoices/credit notes, reporting, audit history, e-invoicing, AI tax recommendations.
- **162 — Financial Crime Prevention Platform:** AML, KYC, KYB, CDD/EDD, sanctions screening, PEP screening, adverse media screening; transaction monitoring, suspicious-activity detection, case management, risk scoring, network analysis, fraud-ring detection, AI behavioral analytics, financial-crime dashboards.
- **163 — Supply Chain Management:** suppliers, procurement planning, manufacturing integration, POs, supplier contracts, lead-time/supply forecasting, inventory optimization, procurement analytics, vendor scorecards, AI supply forecasting.
- **164 — Logistics Network:** courier integrations, fleet/driver management, route optimization, delivery scheduling, real-time tracking, proof of delivery, delivery analytics, cold chain, cross-border/reverse logistics, AI route optimization.
- **165 — Procurement Platform:** supplier registration, RFI/RFQ/RFP, tender management, bid evaluation, purchase approvals, contract management, supplier performance, procurement dashboards.
- **166 — Government & Regulated Industry Edition:** government procurement, public tenders, multi-agency workflows, regulatory reporting, public records retention, accessibility compliance, digital evidence preservation, regulatory audit trails, sector-specific compliance profiles, public sector dashboards.
- **167 — Learning & Certification Platform:** vendor academy, customer learning center, staff training, AI learning assistant, certification programs, assessments, digital certificates, learning paths, progress tracking, CE credits, learning analytics.
- **168 — Community & Collaboration Platform:** discussion forums, product/vendor/customer communities, Q&A, knowledge sharing, reputation system, badges, events, webinars, community moderation, AI community assistant.
- **169 — Data Platform & Analytics Lake:** data lake/warehouse, ETL/ELT, streaming/batch processing, AI training datasets, self-service analytics, data catalog/sharing, governance integration, enterprise reporting.
- **170 — Integration Gateway & Operational Governance:** enterprise API gateway, API lifecycle mgmt, API marketplace/analytics/monetization, webhooks, event streaming, service mesh, message brokers, integration designer, partner portal; future cryptography (crypto-agility, post-quantum readiness, key-rotation framework, algorithm migration); operational governance (ADRs, Secure Development Lifecycle, threat modeling, change/release management, incident response playbooks, BC plans, DR procedures, capacity planning, SLOs/SLIs/SLAs, runbooks, production readiness reviews).

**Engineering standards required for Parts I–XIII as a whole:** Clean Architecture/DDD/event-driven/CQRS/Saga/API-first/additive migrations · Zero Trust, encryption everywhere, HSM support, secrets mgmt, continuous security testing, SBOM, supply-chain security · HA, multi-region, horizontal scaling, idempotency, circuit breakers, DLQs, automated failover, graceful degradation · OpenAPI/AsyncAPI specs, versioned APIs, full test pyramid, chaos engineering, automated quality gates, CD pipelines.

---

### 20.6 — Part XIV: Enterprise Platform Intelligence, Governance & Experience (Steps 171–180, v3.6)

- **171 — Search Intelligence Platform (doubles as the AI Knowledge Base, v4.7 merge):** full-text/semantic/vector/hybrid/AI/voice/image/barcode/QR/NL search; autocomplete, spell correction, synonyms, suggestions, faceted search, dynamic filters, saved/personalized/trending searches, search merchandising, AI ranking, multi-language; analytics on success rate, zero-result queries, popular queries, conversion, CTR. v4.7 addition merged in rather than duplicated: natural-language enterprise search that spans **documents, policies, vendors, orders, contracts, conversations, products, and support tickets** as first-class searchable entity types, using the same semantic/vector index as product search — powered jointly by this step's search index and the entity-relationship modeling already defined in the Knowledge Graph & Semantic Intelligence step (Step 159). Underlying entity sources are not new tables: documents/contracts come from Document & DAM (Step 151) and Contract Lifecycle Management (Step 184), policies from Policy Management (Step 186), conversations from Step 126/Real-Time Collaboration (Step 188), and support tickets from CRM & Customer 360 (Step 145).
- **172 — Consent & Privacy Preference Center:** cookie/marketing/email/SMS/push/WhatsApp/AI-personalization/data-sharing consent; consent history/versioning, preference center, privacy dashboard, self-service export/deletion requests, consent audit trail.
- **173 — Scheduling & Calendar Platform:** appointment scheduling, booking calendars, resource/staff scheduling, vendor availability, delivery scheduling, time-zone mgmt, recurring events, calendar sync, AI scheduling assistant, capacity planning.
- **174 — Forms & Workflow Builder:** drag-drop form builder, dynamic/conditional forms, file uploads, e-signatures, approval workflows, multi-step forms, validation rules, templates, AI form generation, workflow integration.
- **175 — Secrets & Key Management Platform:** secrets vault, encryption keys, certificate management, HSM/cloud KMS integration, automatic secret/certificate rotation, API key management, signing keys, encryption policies, access auditing.
- **176 — FinOps & Cost Intelligence Platform:** cloud/AI-model/storage/API/database/network cost analysis, marketplace revenue, vendor profitability, CAC, ROI dashboards, cost forecasting, budget alerts.
- **177 — Identity Verification Marketplace:** provider-agnostic KYC/KYB, gov ID/passport/driver-license/address verification, face verification, liveness detection, AML/sanctions screening, business registry verification; multi-provider framework with failover, comparison, cost optimization, health monitoring, AI recommendations.
- **178 — Trust & Reputation Platform:** customer trust score, purchase/payment reliability, dispute history, community reputation; vendor seller-trust score, delivery performance, product quality, satisfaction, cancellation/return rate, response time, verification level; AI continuously updates scores with explainability/auditability.
- **179 — Experimentation & Feature Optimization Platform:** A/B and multivariate testing, feature/AI experiments, canary releases, experiment dashboards, statistical analysis, automatic rollback, AI experiment recommendations, performance comparison.
- **180 — Metadata, Governance & Architecture Repository:** configurable metadata for products/categories/vendors/customers/orders/wallets/payments/shipments/warehouses/documents/AI agents/workflows/notifications/reports; architecture governance repository (ADRs, DDD domain map, bounded contexts, ubiquitous language glossary, coding/API/UI standards, naming conventions, versioning strategy, DB/event standards, security baselines, performance budgets, dependency policies, doc standards, release governance, deprecation policies, technology radar, approved framework registry); enterprise governance (policy mgmt, SOPs, compliance checklists, governance dashboards, risk register, decision logs, audit readiness, architecture reviews, CAB workflows).

**Database tables:** `search_indexes`, `search_queries`, `search_analytics`, `search_synonyms`, `search_merchandising_rules`, `consent_records`, `privacy_requests`, `communication_preferences`, `calendars`, `calendar_events`, `resource_schedules`, `dynamic_forms`, `form_submissions`, `workflow_forms`, `secret_store`, `certificate_store`, `key_rotation_logs`, `cost_centers`, `cost_reports`, `cost_forecasts`, `identity_providers`, `identity_verifications`, `verification_results`, `trust_scores`, `reputation_history`, `experiments`, `experiment_variants`, `experiment_results`, `metadata_definitions`, `metadata_values`, `architecture_decisions`, `engineering_standards`, `technology_radar`, `governance_policies`, `risk_register`.

**Design principles required for Parts I–XIV as a whole:** AI-first with human-in-the-loop + explainability + prompt/model governance · cloud-native (K8s-ready, containerized, auto-scaling, multi-region, IaC) · secure by design (Zero Trust, least privilege, defense in depth, secure defaults, continuous validation) · observable by default (metrics/logs/traces/health checks/AI observability/business KPIs) · backward compatibility (additive migrations, API/event versioning, config migration support, LTS strategy).

---

### 20.7 — Part XV: Commerce Operating System & Enterprise Intelligence (Steps 181–190, v3.7)

- **181 — AI Agent Operating System (AI Agent OS):** dynamic agent registry/discovery/lifecycle/scheduling/orchestration, agent-to-agent comms, multi-agent collaboration, short/long-term agent memory, shared context, agent permissions, health monitoring, cost tracking, versioning, prompt versioning, tool registry, human-in-the-loop approval, AI safety guardrails, explainability/audit logs. Specialized agent categories (v4.7 merge — aligned with the "example enterprise agents" list requested for an AI Agent Marketplace): marketplace ops, customer support, sales, marketing, SEO, product photography, inventory, fraud, accounting, HR, procurement, legal, compliance, cybersecurity, infrastructure, BI, content moderation, vendor success, logistics, finance. **This is the formal home for the "20,000 dynamic agents, not fixed agents" concept first introduced in Part VII (AI-SOC, Step 127) — treat AI-SOC's agent orchestration as a specialization running on top of this OS, not a separate framework.** The consumer-facing side of this same OS — installable agents, an Agent Store, third-party publishing, agent permissions at install time, billing, ratings, update management, and revenue sharing — is **not duplicated here**; it already lives at **Step 247 (Marketplace for Apps, Extensions & AI Agents, Section 20.10)**, which this step's agent registry feeds directly.

**v4.8 addition — 200 AI Customer Care Agents & Visual Product Discovery (a concrete customer-support specialization running on this same AI Agent OS, not a new agent framework):** a coordinated workforce of 200 specialized (not identical) Customer Care agents, registered and orchestrated through this step's agent registry/scheduling/memory/permission machinery. Each agent has a fixed name, avatar, personality, communication style, specialization, language set, and escalation rules (identity never changes mid- or cross-conversation), and is always labeled as AI (e.g. "Maya Johnson — AI Customer Care Specialist") — never claims to be human, physically present, or to have personally handled a physical task. Agents are organized into departments (Marketplace Support, Product Specialists, Order Support, Payment Support, Vendor Support, Affiliate Support, Event & Ticket Support, Travel & Service Support, Dispute & Escalation) and are auto-routed by intent detection so the customer experiences one continuous conversation even when the backend hands off between specialists or to a human (handoff/escalation reuses this step's existing agent-to-agent comms and shared context — no new handoff mechanism). Agents draw only on data they're permissioned for, from the existing Marketplace, Orders, Payments, Wallet, Gift Card, Affiliate, Events, and Travel modules — never a new data layer. **Visual product discovery:** customers can upload an image inside the conversation; the agent runs image analysis and a similarity search against the **existing** product embeddings/vector search (Search Intelligence Platform, Step 171) and product media (Step 129), applies metadata/location/price/availability filters, and presents ranked lookalike/cheaper/premium/different-color alternatives conversationally, with natural-language refinement ("show this in black", "cheaper", "only in Lagos"). A supervisory layer (running on this same AI Agent OS's monitoring/health capabilities) watches all 200 agents for routing quality, policy violations, and hallucinations, and can reassign conversations but cannot bypass any authorization control. Performance analytics (resolution rate, escalation rate, CSAT, recommendation conversion) are surfaced through the existing BI Dashboard (Step 138), not a new analytics stack.
- **182 — Digital Identity & Credential Platform:** digital customer/vendor/employee/org IDs, digital certificates, verifiable credentials (VC), decentralized identity (DID) readiness, credential wallets, revocation/expiration, identity federation, trust chains, digital badges.
- **183 — Enterprise Asset Management (EAM):** physical/IT/software assets, hardware inventory, vehicles, warehouses, buildings, equipment, licenses; assignment, maintenance scheduling, preventive maintenance, depreciation, audits, lifecycle tracking.
- **184 — Contract Lifecycle Management (CLM):** contract authoring, AI drafting, clause library, version control, approval workflow, negotiation tracking, e-signatures, renewal management, obligation tracking, compliance monitoring, contract analytics, risk scoring.
- **185 — Master Data Management (MDM):** single source of truth for Customer/Vendor/Product/Organization/Category/Brand/Currency/Tax/Location/Supplier masters; golden record management, duplicate detection, record merging, data stewardship, validation rules, quality scoring, lineage integration, ERP/CRM sync.
- **186 — Policy Management Platform (doubles as the Enterprise Audit & Compliance Center, v4.7 merge):** centralizes security/marketplace/AI-governance/privacy/compliance/data-retention/vendor/customer/financial/moderation policies; versioning, approval workflows, effective dates, policy enforcement APIs, compliance monitoring, audit logs. v4.7 additions merged in rather than duplicated: **compliance dashboards**, an **evidence repository** (attaches supporting documents/screenshots/logs to a policy or audit finding — built on the Document & Digital Asset Management tables from Step 151), **approval chains**, **compliance/audit reporting**, and an **AI compliance assistant** (surfaces the relevant compliance-summary output already produced by the Admin AI Copilot at Step 137). This step is the compliance dashboard layer sitting on top of — not replacing — the risk register/governance repository at Step 180, the Security Repository at Step 229, and the Platform Governance Charter at Step 270; retention-policy and right-to-access/delete mechanics remain owned by Data Governance & Privacy (Step 147).
- **187 — Content Intelligence Platform:** DAM, image/video/audio/document management, AI image/video tagging, OCR, speech-to-text, video transcoding, AI content classification, brand asset libraries, CDN optimization, copyright tracking, content moderation.
- **188 — Real-Time Collaboration Platform:** team chat, secure messaging, voice/video calls, screen sharing, shared whiteboards, live document collaboration, shared workspaces, presence/cursors, file collaboration, meeting recording, AI meeting summaries, translation/live captions. (Distinct from the customer-facing Step 126 communication system — this is internal enterprise collaboration.)
- **189 — Edge Computing & Offline Platform:** offline-first mobile apps, offline POS mode, edge sync, local caching, conflict resolution, background sync, remote-branch support, local AI inference where supported, bandwidth optimization, intelligent sync policies.
- **190 — Command Center & Global Operations Console (also the platform's AI Command Center, v4.7 merge):** unified real-time dashboards for marketplace health, payment ops, wallet activity, escrow status, orders/fulfillment, vendor performance, customer activity, AI agent status, security ops, fraud monitoring, logistics, infra health, API performance, business KPIs, incident management, global heat maps, digital-twin integration, predictive alerts, executive cockpit. v4.7 addition merged in here rather than as a new module: a **unified natural-language command interface** — e.g. "show declining vendors", "freeze account", "generate revenue report", "create coupons", "update inventory", "launch campaign", "schedule workflow" — that routes the parsed intent to the correct existing module/API (Vendor Success Center Step 136, Wallet/Fraud Steps 9–10, BI Dashboard Step 138, Promotion Engine Step 130, Inventory Step 132, Workflow Automation Step 139) via the AI Agent OS (Step 181) rather than a separate command-parsing stack.

**Database tables:** `ai_agents`, `ai_agent_registry`, `ai_agent_versions`, `ai_agent_memory`, `ai_agent_tasks`, `ai_agent_tools`, `ai_agent_health`, `digital_identities`, `digital_credentials`, `credential_wallets`, `enterprise_assets`, `asset_categories`, `asset_assignments`, `asset_maintenance`, `contracts`, `contract_versions`, `contract_clauses`, `contract_obligations`, `master_data_records`, `master_data_domains`, `master_data_quality`, `enterprise_policies`, `policy_versions`, `policy_audit_logs`, `digital_assets`, `content_tags`, `media_transcoding_jobs`, `collaboration_spaces`, `meetings`, `meeting_recordings`, `shared_documents`, `edge_nodes`, `offline_sync_jobs`, `sync_conflicts`, `command_center_dashboards`, `operational_alerts`, `executive_reports`.

**Reference architecture required (mandatory, maintained as a living repository):** C4 context/container/component/code diagrams, DDD bounded-context maps, event-storming artifacts, sequence diagrams, ER diagrams, API interaction diagrams, network/K8s topology, cloud/DR/security/AI/data/integration/deployment architecture. Plus engineering standards: API design, DB, event-naming, logging, observability, coding, UI/UX design system, WCAG 2.2 AA, AI governance, SDL, threat modeling, performance budgets, versioning strategy, documentation standards.

> **Part XVI (Steps 191–200) gap:** not defined in any spec material supplied. Do not build against assumed content.

---

### 20.8 — Part XVII: Enterprise Engineering Blueprint & Delivery Standards (Steps 201–220, v4.1)

This Part shifts from "what to build" to "**how the platform is engineered**." Each step below defines a mandatory artifact/repository, not a user-facing feature.

| Step | Deliverable | Must define/maintain |
|---|---|---|
| 201 | API Specification Repository | OpenAPI 3.1, GraphQL schema registry, AsyncAPI, WebSocket specs, optional internal gRPC; every API documented with auth, request/response schema, error codes, pagination, filtering, sorting, rate limits, examples, SDK samples, version history, deprecation schedule. |
| 202 | Event Catalog | Every platform event (e.g. `UserRegistered`, `VendorApproved`, `ProductCreated`, `OrderPaid`, `EscrowReleased`, `ChatReported`, `SecurityIncidentDetected`, `AIAgentStarted`) with owner, producer, consumer, payload schema, version, retry strategy, idempotency rules, DLQ policy, retention policy. |
| 203 | Database Architecture | ER diagrams, FKs, index strategy, constraints, partitioning, replication, archiving, backup strategy, migration plan, data ownership. |
| 204 | Microservice Architecture | Per-service: responsibilities, APIs, DB ownership, event ownership, scaling policy, security model, health checks, dependencies, SLA/SLO/error budget. |
| 205 | Reference Architecture | C4 model, context/container/component/deployment diagrams, DDD context map, event storming, sequence diagrams, infra/network diagram, security/AI/data architecture. |
| 206 | Infrastructure as Code | Terraform, Helm, K8s manifests, Docker Compose (dev), GitOps, environment/secrets templates, automated provisioning. |
| 207 | CI/CD & DevSecOps | Automated build pipelines, unit/integration/E2E tests, security/dependency/license/container scanning, infra validation, automated deployment, canary & blue-green releases. |
| 208 | Testing Framework | Unit, integration, contract, API, E2E, UI, load, stress, soak, chaos engineering, security, accessibility, AI evaluation testing. |
| 209 | Security Engineering | Threat models, STRIDE analysis, attack trees, security architecture reviews, secure coding standards, penetration testing, red-team exercises, vulnerability management, supply-chain security, SBOM generation. |
| 210 | AI Engineering Standards | Prompt registry/versioning, model registry/evaluation, AI guardrails, human review, hallucination testing, bias evaluation, cost optimization, AI audit logs. |
| 211 | UI/UX Design System | Design tokens, typography, color system, icon library, components, accessibility rules, animation standards, responsive/mobile/desktop patterns. |
| 212 | Documentation Portal | Developer/API docs, user/admin guides, ops manuals, SDK docs, AI docs, release notes, migration guides, troubleshooting guides. |
| 213 | Operational Runbooks | Incident response, DR, business continuity, deployment/rollback procedures, backup restoration, capacity expansion, maintenance windows. |
| 214 | Compliance Mapping | Maps platform controls to PCI DSS, ISO/IEC 27001, SOC 2, GDPR, CCPA, HIPAA (where applicable), PSD2/Open Banking (where applicable), regional financial regulations. |
| 215 | Performance Engineering | Performance budgets, capacity planning, scalability/latency/throughput/availability/error-budget targets. |
| 216 | Release Governance | Semantic versioning, release branches, LTS, CAB, release approval workflow, deprecation/EOL policy. |
| 217 | Developer Experience (DX) | CLI tools, local dev environment, mock services, test-data generators, API sandbox, SDK samples, starter templates, plugin dev kit. |
| 218 | Quality Gates | No release proceeds without: code quality, security review, architecture review, performance validation, accessibility validation, AI safety review, documentation review, test-coverage thresholds. |
| 219 | Support & Operations | 24/7 monitoring, service desk, incident/problem/change/config/asset/knowledge management, SLA reporting. |
| 220 | Continuous Improvement Framework | KPI reviews, architecture/security/AI-performance reviews, customer/vendor feedback loops, technical debt management, innovation backlog, quarterly platform reviews, annual architecture refresh. |

**Mandatory enterprise deliverables from this Part on:** Enterprise Specification, Architecture Repository, API Repository, Event Catalog, Database Schema Repository, Infrastructure Repository, Security Repository, AI Governance Repository, Design System Repository, Operations Repository, Compliance Repository, Developer Portal — plus OpenAPI specs, GraphQL schemas, AsyncAPI specs, ER/C4/DDD/sequence diagrams, threat models, test plans, deployment guides, DR plans, runbooks, SDKs, reference implementations.

---

### 20.9 — Part XVIII: Enterprise Delivery Framework & Reference Implementation (Steps 221–240, v4.2)

Formalizes Part XVII's standards into concrete, maintained repositories. One step per repository/framework:

| Step | Repository / Framework | Scope |
|---|---|---|
| 221 | Reference Implementation Repository | Backend/frontend/mobile/AI-agent/API-gateway/auth/payment/marketplace/notification/security/observability reference builds, following Clean Architecture, DDD, SOLID, 12-Factor App, event-driven, API-first. |
| 222 | API Repository | OpenAPI 3.1, GraphQL schemas, AsyncAPI, WebSocket/gRPC contracts, SDK generation, mock servers, test collections, changelog. |
| 223 | Database Repository | SQL schema, ER diagrams, index/constraint definitions, partition/replication strategy, seed data, migration + rollback scripts, data dictionary. |
| 224 | Event Repository | Official event catalog with name, description, payload schema, version, producer/consumers, ordering guarantees, retry, DLQ, retention, security classification. |
| 225 | Architecture Repository | C4, DDD context maps, sequence/deployment/integration diagrams, security/AI/data/network/cloud architecture. |
| 226 | Infrastructure Repository | Terraform, Helm, K8s manifests, Docker images/compose, GitOps config, secret templates, monitoring config. |
| 227 | Design System Repository | Design tokens, typography, color palette, icon library, component library, responsive layouts, accessibility guidelines, motion standards, branding assets, Figma library. |
| 228 | AI Repository | Prompt library, agent definitions/templates, tool definitions, eval benchmarks, guardrail policies, AI test cases, prompt version history, cost dashboards, safety reports. |
| 229 | Security Repository | Threat models, STRIDE, attack trees, risk register, security baselines, hardening guides, cryptography standards, secrets management, incident response playbooks, pen-test reports. |
| 230 | Testing Repository | Unit/integration/API/contract/UI/mobile/load/stress/chaos/security/accessibility/AI-validation test suites. |
| 231 | DevSecOps Framework | CI/CD, GitOps, code/security quality gates, container/dependency scanning, SBOM, artifact signing, automated rollback, deployment approvals. |
| 232 | Developer Experience Platform | CLI tools, project generators, local dev env, mock services, API sandbox, test data factory, SDK samples, extension SDK, plugin templates. |
| 233 | Documentation Platform | Developer portal, API docs, architecture handbook, user/admin guides, AI docs, deployment guides, ops manuals, troubleshooting guides, release notes. |
| 234 | Operations Framework | Incident/problem/change/release management, capacity planning, on-call procedures, escalation matrix, maintenance windows, service reviews. |
| 235 | Compliance Evidence Framework | Maintains evidence for PCI DSS, ISO 27001, SOC 2, GDPR, CCPA, PSD2/Open Banking, regional regulations, internal audit. |
| 236 | Performance Engineering Framework | Performance budgets, capacity models, scalability/load/stress profiles, latency/throughput/availability objectives. |
| 237 | Release & Lifecycle Management | Semantic versioning, LTS releases, release trains, feature-branch strategy, deprecation policies, migration guides, upgrade assistant, rollback strategy. |
| 238 | Knowledge Management | Knowledge base, ADRs, lessons learned, engineering playbooks, best practices, technical standards, FAQs, operational knowledge articles. |
| 239 | Governance & Portfolio Management | Strategic roadmaps, portfolio/program management, project tracking, technical debt register, risk register, innovation backlog, investment tracking, executive dashboards. |
| 240 | Continuous Evolution Framework | Quarterly architecture reviews, annual platform reviews, technology-radar updates, security-posture reviews, AI-model reviews, compliance reviews, customer/vendor feedback analysis, performance-trend analysis, innovation governance. |

**Enterprise success criteria — a release is production-ready only if:** 100% API contract validation passes · additive DB migrations succeed · security gates pass · AI safety validation passes · performance objectives met · WCAG 2.2 AA compliance verified · DR validation completed · observability coverage verified · docs updated · compliance evidence generated · runbooks approved · executive production-readiness review completed.

---

### 20.10 — Part XIX: Enterprise Platform Innovation & Digital Ecosystem (Steps 241–260, v4.3)

- **241 — Low-Code/No-Code Development Platform:** application builder (drag-drop page/screen builder, responsive layout designer, component library, theme builder, white-label, multi-tenant UI templates, AI UI generator); business logic builder (visual workflow designer, decision tables, rule engine, formula builder, conditional logic, scheduled jobs, event triggers, AI workflow generation); data builder (custom objects/tables/relationships, dynamic fields, metadata mgmt, schema versioning, validation rules); API builder (REST/GraphQL generators, webhook builder, integration wizard, auth config, API testing console); report builder (drag-drop reports, custom dashboards, KPI widgets, AI insights, scheduled reports, interactive charts).
- **242 — Enterprise Integration Marketplace:** certified connectors for ERP/CRM/accounting/payment/banking/logistics/shipping/marketing/email/SMS/AI/identity/cloud-storage/analytics/government services; one-click install, OAuth config, versioning, health monitoring, usage analytics, ratings, revenue sharing, partner certification, auto-updates, sandbox testing.
- **243 — Digital Twin Platform:** twins for marketplace, warehouse, logistics, infrastructure, financial, customer-journey, vendor-ops, security-ops, AI-ops, network; real-time sync, predictive analytics, capacity modeling, failure simulation, AI recommendations, historical replay, operational dashboards.
- **244 — Business Simulation Platform:** simulate pricing, promotions, tax, inventory, supply chain, logistics, fraud rules, security policy, AI decisions, marketplace rules, financial forecasts before deployment; scenario comparison, impact analysis, AI recommendations, rollback planning, executive reports.
- **245 — Innovation Laboratory:** AI model sandbox, feature-flag testing, prototype apps, beta programs, experimental integrations, controlled rollouts, A/B & multivariate testing, innovation analytics, feedback collection, governance approval.
- **246 — Ecosystem & Partner Platform:** partner types (technology, payment, logistics, government, financial institutions, AI providers, marketplace sellers, enterprise customers, independent developers, system integrators); partner portal, certification, revenue sharing, analytics, joint solutions, marketplace listings, partner APIs.
- **247 — Marketplace for Apps, Extensions & AI Agents (confirmed as the AI Agent Marketplace, v4.7 merge):** extension/plugin/theme/workflow/dashboard/report/AI-agent/prompt/automation/connector marketplaces; digital signatures, security validation, version management, licensing, billing, reviews, auto-updates, **third-party agent publishing, per-agent permissions, and revenue sharing** (v4.7 — made explicit alongside the existing licensing/billing fields). Installable AI agents draw their capability list from the specialized agent categories already defined at Step 181.
- **248 — Organization Builder:** multi-level orgs, departments, divisions, cost centers, business units, subsidiaries, franchise networks, multi-brand mgmt, multi-country structures, delegated administration.
- **249 — Knowledge & Learning Platform:** LMS, knowledge base, interactive tutorials, certification programs, AI learning assistant, documentation portal, training videos, skill assessments, developer/vendor/admin academies.
- **250 — Platform Marketplace Governance:** extension approval workflow, security review, code signing, malware scanning, license compliance, marketplace moderation, policy enforcement, revenue settlement, dispute resolution, marketplace analytics.
- **251–260 — "Future-Ready Platform Standards" (reserved, governance-gated):** quantum-ready cryptography integration, post-quantum security migration, digital asset tokenization (where legally permitted), autonomous AI governance enhancements, sustainability/ESG reporting, carbon footprint analytics, smart-city integrations, industrial IoT integration, emerging regulatory framework support, next-gen commerce innovations. **These are explicitly reserved slots, not steps to build speculatively — build only when a specific, governance-approved need arises, and keep additions modular/optional/backward-compatible.**

**Recommended 20-volume documentation library (from this Part's advisory content):** Enterprise Core Platform · Marketplace Engine · Product Catalog & Inventory · Fintech, Wallet & Payments · Banking & Financial Integrations · AI Platform & AI Agent OS · Cybersecurity & SOC · Search, Analytics & BI · Developer Platform & SDKs · API & Integration Guide · Database & Data Architecture · Infrastructure & DevOps · UI/UX Design System · Operations & Support · Governance, Compliance & Risk · Administrator Guide · Vendor Guide · Customer Guide · Partner & Integration Guide · Deployment & DR Guide.

---

### 20.11 — Part XX: Enterprise Platform Governance, Global Readiness & Cross-Cutting Standards (Steps 261–270, v4.4)

- **261 — Data Governance & Data Mesh Platform:** domain-based data ownership, data mesh architecture, data products, enterprise data catalog, business glossary, metadata repository, data lineage, master metadata registry, data stewardship, quality monitoring/profiling/validation, classification, sensitive-data/PII tagging, retention/archiving/lifecycle, data contracts, cross-service sharing, AI + regulatory data governance.
- **262 — Observability & Reliability Platform:** centralized logging, distributed tracing, metrics, business-KPI monitoring, AI model/agent observability, API/DB/infra monitoring, RUM, synthetic monitoring, service dependency mapping, SLO/SLA dashboards, error-budget tracking, root-cause analysis, alert correlation, predictive failure detection, executive ops dashboard.
- **263 — Accessibility & Inclusive Design Framework:** WCAG 2.2 AA, keyboard nav, screen reader compatibility, high-contrast themes, reduced motion, adjustable font sizes, color-blind accessibility, captions/transcripts, focus indicators, accessible forms/charts, voice-nav readiness, AI accessibility assistant, automated testing, audit reports.
- **264 — i18n & l10n:** unlimited languages + RTL, locale-aware date/time, currency/tax/address/phone localization, regional holiday calendars, time zones, multi-language search, AI translation assistance, translation workflow, localized CMS content, regional compliance rules, country-specific business logic.
- **265 — Sustainability & ESG Intelligence:** carbon footprint tracking, energy consumption monitoring, infra efficiency metrics, cloud sustainability metrics, green hosting analytics, vendor sustainability scores, supplier ESG evaluation, sustainability dashboards, carbon-reduction goals, ESG reports, regulatory sustainability reporting, benchmarking.
- **266 — Business Rules & Decision Management Platform:** visual rule editor, decision tables/trees, rule versioning/approval/testing/simulation/audit trail, runtime rule updates, AI-assisted rule authoring, rule templates/marketplace, performance analytics. Rule domains: pricing, promotions, marketplace policies, tax, commission, shipping, fraud, escrow, payment routing, wallet limits, KYC, AI governance policies.
- **267 — Documentation Architecture:** replaces the single spec with a 16-volume structured library (Core Platform; Marketplace & Commerce; Product Catalog & Inventory; Fintech, Wallet & Payments; AI Platform & AI Agent OS; Cybersecurity & SOC; Search/Analytics/BI; Developer Platform & SDKs; API & Integration Specs; Database & Data Architecture; Infrastructure & DevOps; UI/UX Design System; Operations & Support; Governance, Risk & Compliance; Deployment/DR/BC; Administrator/Vendor/Customer Guides).
- **268 — Platform Certification Framework:** per-release certifications for architecture, security, performance, accessibility, AI governance, compliance, DR, scalability, marketplace, payment, mobile.
- **269 — Platform Maturity Model:** measures architecture, security, AI, data governance, observability, operations, DX, marketplace ops, customer experience, vendor success, compliance, and platform reliability across maturity Levels 1 (Initial) → 5 (Optimized), with measurable assessment criteria and continuous improvement plans.
- **270 — Platform Governance Charter:** governance bodies (Enterprise Architecture Board, AI Governance Council, Security Review Board, Data Governance Council, Compliance Committee, Platform Engineering Council, Product Steering Committee, CAB) with responsibilities spanning feature approval, architecture/security/AI-ethics review, compliance oversight, technology adoption, version management, risk acceptance, deprecation decisions, and platform roadmap management.

**Cross-cutting standards (explicit, apply to all Parts I–XX):** AI-first with human oversight · Zero Trust security · cloud-native architecture · event-driven design · API-first development · accessibility by design · privacy by design · secure by default · observable by default · internationalization by default · sustainability by design · backward-compatible evolution · infrastructure as code · continuous compliance · continuous testing · continuous delivery.

> **Part XXI (Steps 271–280) gap:** not defined in any spec material supplied. Do not build against assumed content.

---

### 20.12 — Part XXII: Enterprise Gift Card Generation & Management Platform (Steps 281–290, v4.6)

**Overview:** complete lifecycle for creating, issuing, distributing, redeeming, securing, tracking, and managing digital + physical gift cards, for consumers, businesses, vendors, enterprises, and partners. Integrates with Wallet, Marketplace, Payment Engine, Loyalty, CRM, ERP, POS, AI Platform, Analytics — **complements, does not duplicate, the existing Wallet (Steps 8–9) and original Gift Card System (Step 8).**

| Step | Module | Key capabilities |
|---|---|---|
| 281 | Gift Card Generation Engine | Card types: digital, physical, printable PDF, QR, barcode, NFC, virtual-wallet, corporate, employee-reward, promotional, marketplace, vendor, brand-specific, multi-vendor, country-specific, multi-currency, subscription, event, charity, cashback. Value options: fixed/custom value, min/max limits, multi-currency values, regional pricing rules, tax configuration. |
| 282 | Secure Issuance & Lifecycle Management | Lifecycle: `Draft → Generated → Activated → Scheduled → Delivered → Redeemed/Partially Redeemed → Suspended → Frozen → Locked → Reloaded → Expired → Extended → Reissued → Cancelled → Archived`. Generation: cryptographically secure random codes, batch/bulk generation, secure PIN, QR/barcode generation, custom prefixes/branding, sequential or randomized numbering, duplicate prevention, digital signature validation. |
| 283 | Marketplace & Distribution Platform | Channels: marketplace storefront, vendor store, corporate portal, mobile/web, POS, API, WhatsApp, email, SMS, push, printable PDF, QR sharing, wallet delivery. Gifting features: scheduled delivery, personalized messages, birthday/holiday/anniversary campaigns, group gifting, anonymous gifting, recurring gifts. |
| 284 | Wallet Integration | Balance inquiry, multiple cards, auto-apply at checkout, partial redemption, combine multiple cards, remaining-balance tracking, transaction history, expiration reminders, wallet storage, Apple/Google Wallet compatibility (where supported), offline verification tokens. |
| 285 | Vendor & Corporate Gift Card Management | Vendor portal: creation, campaign mgmt, sales/redemption reports, customer analytics, inventory monitoring, promotion config, branding. Corporate portal: bulk generation, employee/customer rewards, marketing campaigns, department budgets, approval workflow, CSV import/export, expense tracking, spending analytics. |
| 286 | Security, Fraud Detection & Compliance | AI fraud detection, duplicate-redemption prevention, velocity checks, device fingerprinting, IP reputation, geo-risk detection, behavioral analytics, redemption risk scoring, tamper detection, brute-force protection, secure token validation, digital signatures, audit logs. Compliance: AML monitoring (where applicable), KYC integration (regulated corporate issuance), PCI DSS, regional financial compliance, data privacy compliance. |
| 287 | Redemption & Payment Integration | Accepted at marketplace checkout, wallet funding (where permitted), subscriptions, service payments, digital/physical products, bookings, utility payments (configurable); partial/split/combined payments, refund-to-gift-card, store-credit conversion, promotional-credit conversion. |
| 288 | AI Gift Card Intelligence Platform | Fraud prediction, redemption prediction, customer segmentation, personalized gift recommendations, dynamic promotions, campaign optimization, gift-purchase forecasting, breakage prediction (unused-balance forecasting), expiration-reminder optimization, churn prevention, LTV analysis, enterprise recommendation engine. |
| 289 | Enterprise Analytics & Reporting | Executive dashboards: cards generated/sold/activated, redemption rate, outstanding liability, breakage analysis, vendor performance, corporate usage, campaign performance, geographic distribution, revenue/fraud analytics, customer engagement, AI performance metrics. Export: PDF, Excel, CSV, JSON, API. |
| 290 | API & Ecosystem Integration (expanded, v4.8 — External Gift Card Payment Acceptance & Settlement) | REST, GraphQL, webhooks, async events, SDKs, bulk APIs, partner APIs. Integrates with: Marketplace Engine, Product Catalog, Cart, Checkout, Wallet, Escrow, Unified Payment Engine, Subscription Platform, Loyalty & Rewards, Coupon & Promotion Engine, Referral Platform, CRM, ERP, POS, AI Platform, Analytics, BI, Notification Center, Vendor/Customer Portal, Super Admin Console, Enterprise Reporting, Mobile Apps, Public APIs, Developer SDKs. **v4.8 addition:** external platforms/merchants can accept WMPC Gift Cards as a payment method — onboarding (business registration, KYC/KYB where required, settlement account config, sandbox vs production credentials, no production keys before approval); payment flow (session → gift card verification: exists/active/sufficient balance/not expired/not frozen/within limits → fraud/risk checks → authorize → capture → ledger entry → settlement), with states `Created → Pending → Authorized → Captured → Failed/Cancelled/Refunded/Partially Refunded/Disputed → Settled` and idempotency keys throughout; integration methods: API, hosted payment page, SDKs (web/JS/mobile), embeddable checkout component — all still routed through this step's existing payment infrastructure, never bypassing it. Settlement records (gross amount, WMPC fee, platform fee, refund/chargeback adjustments, net amount, currency, status, schedule) extend the **existing Settlement/Ledger from Steps 8–9 and the Escrow settlement logic (Section 16)** — no new settlement engine. Webhooks (payment created/authorized/captured/failed/refunded, chargeback opened, settlement scheduled/completed/failed) with signature verification and retries. Fraud monitoring, sandbox environment, and Developer Dashboard credential/usage management reuse the existing Fraud Detection Engine (Step 10) and Headless Commerce & Developer Platform (Step 141) — this is an extension of both, not a parallel developer portal. |

**Super Admin controls:** global gift-card configuration, brand/template management, multi-tenant policies, issuance permissions, vendor approval, corporate account management, fraud rule configuration, redemption policies, regional availability, currency support, tax rules, expiration policies, reporting, audit logs, compliance monitoring, AI configuration, emergency card suspension, bulk operations, system-wide analytics.

**Technical standards:** multi-tenant deployments, horizontal scaling, event-driven, API-first, offline validation support, cryptographically secure identifiers, immutable audit logs, HA + DR, encryption in transit and at rest, idempotent issuance/redemption APIs, real-time events for every lifecycle change.

---

### 20.13 — v4.7 Update Merge Report (11 Capability Requests, No New Parts/Steps)

This report is required output per the `update_.txt` "FINAL REQUIREMENT." All 11 requested capabilities were cross-checked against the entire existing spec (Sections 5, 8–20) before any edit was made. **Zero new Parts or Step numbers were created** — every request already had an existing owner.

| # | Requested capability | Verdict | Existing home (unchanged step numbers) | What was actually merged in |
|---|---|---|---|---|
| 1 | Enterprise 3D Product & Event Media System | Expanded existing | Step 129 (§20.1) product media/360°/3D/AR; Step 15 Event Management | Added AI 360 Capture Assistant (guided 6-position phone capture + auto background/align/light/stitch), AI 3D Reconstruction (GLB/GLTF from capture photos), `product_360_capture_sessions` table, and Event Ticket Media (reuses product-media tables for venue walkthroughs/seating/stage/booth previews) |
| 2 | Enterprise Workflow Automation Engine | Expanded existing | Step 139 (§20.2) Workflow Automation Platform | Added BPMN-inspired framing, timers/retries/rollback/versioning/audit logging, exposed workflow APIs, and the three documented example workflows (Vendor Registration, Commerce, Fraud) |
| 3 | AI Agent Marketplace | Expanded existing | Step 181 (§20.7) AI Agent OS + Step 247 (§20.10) Marketplace for Apps/Extensions/AI Agents | Step 181: aligned agent categories with the requested example-agent list (sales, marketing, SEO, product photography, accounting, HR, procurement, legal, etc.) and cross-referenced Step 247 explicitly so the two are never confused as duplicates. Step 247: made third-party publishing, per-agent permissions, and revenue sharing explicit |
| 4 | Developer Platform | Expanded existing | Step 141 (§20.2) Headless Commerce & Developer Platform | Added CLI to the existing SDK list; REST/GraphQL/webhooks/OAuth/API keys/portal/docs/sandbox/rate limits/integration marketplace/versioning were already present |
| 5 | AI Command Center | Expanded existing | Step 190 (§20.7) Command Center & Global Operations Console | Added the unified natural-language command interface (routes parsed intent to Vendor Success, Wallet/Fraud, BI, Promotions, Inventory, Workflow Engine via the Step 181 AI Agent OS) |
| 6 | Enterprise Business Intelligence Center | Expanded existing | Step 138 (§20.2) BI & Executive Dashboard | Added explicit scheduled daily/weekly/monthly report generation/delivery; revenue/CLV/churn/vendor-health/forecasting/fraud-analytics/geo-analytics/executive-summary content already existed |
| 7 | Marketplace App Store | Confirmed, no changes needed | Step 154 (§20.4) Marketplace App Store & Extension Platform | Already covers every requested app category (ERP/CRM/accounting/marketing/shipping/tax/payments/logistics/analytics), lifecycle, billing, and approval process — noted as confirmed rather than edited |
| 8 | AI Knowledge Base | Expanded existing | Step 171 (§20.6) Search Intelligence Platform + Step 159 (§20.4) Knowledge Graph & Semantic Intelligence | Added natural-language search spanning documents, policies, vendors, orders, contracts, conversations, products, and support tickets as first-class entity types, sourced from their existing owning modules (Steps 145, 151, 184, 186, 126/188) rather than new tables |
| 9 | Enterprise Audit & Compliance Center | Expanded existing | Step 186 (§20.7) Policy Management Platform | Added compliance dashboards, an evidence repository (built on Step 151's DAM tables), approval chains, compliance/audit reporting, and an AI compliance assistant; cross-referenced against Step 180 (governance repository), Step 229 (Security Repository), Step 270 (Governance Charter), and Step 147 (retention/right-to-access) so none of the five compliance-adjacent steps duplicate each other |
| 10 | Global Communication Hub | Expanded existing | Step 152 (§20.3) Unified Notification Center | Added the unified per-entity communication timeline (Customer/Vendor/Order/Ticket/Case/Workflow), built on Step 145's existing communication-timeline field; live messaging/voice/video itself stays owned by Steps 126 and 188 |
| 11 | White-Label Enterprise Platform | Confirmed, no changes needed | Step 155 (§20.4) Theme Studio & Experience Builder + Step 157 SaaS & Tenant Management Platform | Already covers branding/domains/themes/colors/logos/multi-tenant architecture/licensing/subscription plans; languages/currencies/payment gateways already owned by Steps 143 and 17 — noted as confirmed rather than edited |

**Confirmation of no duplicate functionality:** every row above resolves to exactly one existing Step; no new database table duplicates an existing one (the single addition, `product_360_capture_sessions`, is a new capture-pipeline table with no prior equivalent); no new Part or Step number was introduced; all existing Session numbers (1–25), Step numbers (1–290, with the Part XVI/XXI gaps unchanged), and document structure are fully preserved and backward compatible.

---

### 20.14 — v4.8 Update Merge Report (4 Capability Requests, No New Parts/Steps)

Same discipline as Section 20.13: all four requested capabilities were cross-checked against the entire existing spec before any edit was made. **Zero new Parts or Step numbers were created** — every request already had an existing owner.

| # | Requested capability | Verdict | Existing home (unchanged step numbers) | What was actually merged in |
|---|---|---|---|---|
| 1 | Vendor-Controlled Affiliate Program | Expanded existing | Steps 101–105 (§8.1), Session 9 | Generalized the digital-product-only affiliate/referral module into a platform-wide program for all vendor types (General/Food/Digital/Service): vendor enable/disable, per-product/per-affiliate/campaign commission rules with a defined priority order, an affiliate product catalog, approval modes, full attribution + commission lifecycle, and multi-vendor order handling — all posting to the existing Wallet/Escrow ledger (Steps 8–9) and Chargeback/Refund system (Step 90), no new ledger |
| 2 | Global Branding Footer ("Proudly Powered by WIL.® / © [year] WINDELS GROUP") | Expanded existing | Step 155 (§20.4) Theme Studio & Experience Builder | Added one reusable `GlobalBrandingFooter`-style component built on this step's existing component library/design tokens, with dynamic-year copyright, responsive horizontal/stacked layout, and light/dark/theme-variant support across web, iOS, Android, Windows, macOS |
| 3 | External Gift Card Payment Integration & Settlement | Expanded existing | Step 290 (§20.12) API & Ecosystem Integration + Step 141 (§20.2) Developer Platform + Steps 8–9 Wallet/Escrow Ledger | Added external merchant onboarding, a gift-card-specific payment/authorization/capture flow, settlement records, webhooks, fraud monitoring, and a sandbox — reusing the existing Fraud Detection Engine (Step 10), Developer Platform (Step 141), and Escrow settlement logic (Section 16) rather than a parallel payments/settlement stack |
| 4 | 200 AI Customer Care Agent Workforce & Visual Product Discovery | Expanded existing | Step 181 (§20.7) AI Agent OS + Step 171 (§20.6) Search Intelligence Platform + Step 129 Product Media | Added 200 named, permission-scoped Customer Care agents as a concrete specialization on the existing AI Agent OS (registry/orchestration/memory/handoff unchanged), routed by intent detection, with image-based lookalike product search running on the existing vector search and product-media pipeline rather than a new search stack; performance analytics surfaced via the existing BI Dashboard (Step 138) |

**Confirmation of no duplicate functionality:** every row above resolves to exactly one existing Step; no new database table duplicates an existing one; no new Part or Step number was introduced; all existing Session numbers (1–25), Step numbers (1–290, with the Part XVI/XXI gaps unchanged), and document structure are fully preserved and backward compatible.

---

## 21. How to Use This File Each Session

1. Open this `CLAUDE.md` plus the live `SESSION_TRACKER.md` progress table.
2. Identify the current/next session from Section 5.
3. Attach the matching source material for that session's steps: `WINDELS_Enterprise_Specification_v3_0.pdf` (Steps 1–125), the v3.1 Part VIII update (Steps 126–128, Section 18), or the relevant Part IX–XXII subsection (Steps 129–290, Section 20).
4. Follow the Global Development Rules in Section 2 — folder structure first, then code.
5. At session end: update the tracker, write the Architecture Decision Log (Section 7 format), and answer the standing conventions question.
6. Never proceed to the next session until the current one's critical rule (if any) is satisfied.
7. For Session 13 (Part VIII) specifically: verify each new sub-system integrates with its existing counterpart (chat → existing chat infra, fraud/AI-SOC → existing fraud engine, SEO → existing SEO layer, security config → existing security architecture) before marking any of Steps 126–128 complete.
8. For Sessions 14–25 (Parts IX–XXII): before starting, re-read the "Feature-Freeze Recommendations" callout at the top of Section 20 and confirm with the product owner that the session's scope is still wanted — the source spec itself flagged several of these Parts as likely unnecessary scope growth. When you reach a Part-XVI or Part-XXI-shaped gap, stop and ask rather than inventing steps.
9. Given the sheer size of Parts IX–XXII, treat Section 20's bullet lists as capability checklists to scope real backlog tickets from — do not attempt to build every bullet in one pass. Slice each session into smaller implementation batches and update the tracker at a finer grain than "whole session done."
10. When implementing any of the 11 v4.7 merged capabilities (Section 20.13), build them inside the existing Step/Session they were merged into — do not create a new session, Part, or Step number for them, and do not re-implement functionality (e.g. billing, licensing, revenue sharing) that a cross-referenced step already owns.
11. When implementing any of the 4 v4.8 merged capabilities (Section 20.14 — affiliate program, branding footer, external gift card payments, AI Customer Care workforce), build them inside Session 9 (Steps 101–105), Session 17 (Step 155), Session 20 (Step 181), or Session 25 (Step 290) as documented — never as a new session or Part number, and never as a second affiliate/settlement/agent-orchestration/search system running alongside the one that already exists.
12. **Finish a session before starting the next one — this is not optional.** A session is only "done" when every step in it has been built end-to-end (backend + frontend, per the vertical-slice rule in Section 2), tested, deployed, entered in `SESSION_TRACKER.md` as ✅ Complete, and confirmed by the product owner. Do not begin Session N+1's folder structure or code — not even to "get ahead" — while any step in Session N is still ⬜/🟡/🔴. If something in the current session is blocked, say so and stop; don't paper over it by starting the next session's work.
